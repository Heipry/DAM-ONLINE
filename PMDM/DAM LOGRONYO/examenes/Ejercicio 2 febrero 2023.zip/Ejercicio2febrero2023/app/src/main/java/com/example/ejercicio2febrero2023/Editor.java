package com.example.ejercicio2febrero2023;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;

public class Editor extends AppCompatActivity {
    EditText edt_texto, edt_tamano;
    RadioGroup rdg_opciones;
    Button btn_volver;

    int size = 0;
    String mayusculas = "";
    String texto_sin_editar = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editor);

        edt_texto = (EditText) findViewById(R.id.edt_texto_editor);
        edt_tamano = (EditText) findViewById(R.id.edt_tamano);
        rdg_opciones = (RadioGroup) findViewById(R.id.rdg_opciones_may_min);
        btn_volver = (Button) findViewById(R.id.btn_volver_editor);

        // Inicializamos estado
        rdg_opciones.clearCheck();
        mayusculas = "";
        texto_sin_editar = "";


        // Listener del botón de volver
        btn_volver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = getIntent();
                if (texto_sin_editar.equals("")) {
                    texto_sin_editar = edt_texto.getText().toString();
                }
                intent.putExtra("texto", texto_sin_editar);
                intent.putExtra("tamano", size);
                intent.putExtra("mayusculas", mayusculas);
                setResult(RESULT_OK, intent);
                finish();
            }
        });

        // Listener para cambiar tamaño
        edt_tamano.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                try {
                    size = Integer.parseInt(String.valueOf(s));
                    edt_texto.setTextSize(size);
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        // Listener para cambiar a mayúsculas/minúsculas
        rdg_opciones.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.rdb_mayusculas:
                        texto_sin_editar = edt_texto.getText().toString();
                        edt_texto.setText(texto_sin_editar.toUpperCase());
                        mayusculas = "mayúsculas";
                        break;
                    case R.id.rdb_minusculas:
                        texto_sin_editar = edt_texto.getText().toString();
                        edt_texto.setText(texto_sin_editar.toLowerCase());
                        mayusculas = "minúsculas";
                        break;
                }
            }
        });
    }
}