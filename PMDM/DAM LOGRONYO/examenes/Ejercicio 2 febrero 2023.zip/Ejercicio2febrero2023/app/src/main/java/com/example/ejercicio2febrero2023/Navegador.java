package com.example.ejercicio2febrero2023;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;

public class Navegador extends AppCompatActivity {
    EditText edt_url;
    Button btn_ir, btn_volver;
    WebView webView;

    String historial = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navegador);

        edt_url = (EditText) findViewById(R.id.edt_url);
        btn_ir = (Button) findViewById(R.id.btn_go);
        btn_volver = (Button) findViewById(R.id.btn_volver_navegador);
        webView = (WebView) findViewById(R.id.webview);

        // Inicializamos la cadena que usamos para enviar datos a la MainActivity
        historial = "";

        btn_volver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = getIntent();
                intent.putExtra("historial_navegador", historial);
                setResult(RESULT_OK, intent);
                finish();
            }
        });

        btn_ir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Operador ternario para actualizar cadena historial:
                // Si está en blanco, añadimos nueva url
                // En caso contrario, añadimos salto de línea y nueva url
                historial += (historial.equals(""))? edt_url.getText().toString() : "\n" + edt_url.getText().toString();

                // Ver apdo. 3 sobre WebView al final de la UD4
                // para entender cómo cargar una página en un WebView
                // con las siguientes líneas:
                webView.getSettings().setJavaScriptEnabled(true);
                webView.setWebViewClient(new WebViewClient());
                webView.setWebChromeClient(new WebChromeClient());
                webView.loadUrl(edt_url.getText().toString());

            }
        });


    }
}