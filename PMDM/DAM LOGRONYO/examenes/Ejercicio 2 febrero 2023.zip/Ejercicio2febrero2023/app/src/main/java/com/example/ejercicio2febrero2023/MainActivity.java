package com.example.ejercicio2febrero2023;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    RadioGroup rdg_opciones;
    Button btn_ir;
    TextView txt_historial;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rdg_opciones = (RadioGroup) findViewById(R.id.rdg_opciones);
        btn_ir = (Button) findViewById(R.id.btn_volver_navegador);
        txt_historial = (TextView) findViewById(R.id.txt_historial);
        
        btn_ir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = null;
                int requestCode = 0;
                switch (rdg_opciones.getCheckedRadioButtonId()) {
                    case R.id.rdb_navegador:
                        intent = new Intent(MainActivity.this, Navegador.class);
                        // Utilizamos el valor 1 para luego detectar que volvemos del NAVEGADOR
                        requestCode = 1;
                        break;
                    case R.id.rdb_editor:
                        intent = new Intent(MainActivity.this, Editor.class);
                        // Utilizamos el valor 2 para luego detectar que volvemos del EDITOR
                        requestCode = 2;
                        break;
                        
                }
                startActivityForResult(intent, requestCode);
            }
        });


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Si volvemos correctamente del NAVEGADOR, actualizamos el historial
        if (requestCode == 1 && resultCode == RESULT_OK) {
            // Comprobamos que no está en blanco
            if (!data.getExtras().getString("historial_navegador").equals("")) {
                txt_historial.append("\n" + data.getExtras().getString("historial_navegador"));
            }
        }

        // Si volvemos correctamente del EDITOR, actualizamos el historial
        if (requestCode == 2 && resultCode == RESULT_OK) {
            // Comprobamos que no está en blanco
            if (!data.getExtras().getString("texto").equals("")) {
                txt_historial.append("\n" + data.getExtras().getString("texto"));
                // Si no se ha editado el tamaño de la fuente se muestra 'sin tamaño'
                // Esto es libre interpretación del enunciado, otras soluciones también
                // son posibles si están razonadas
                if (data.getExtras().getInt("tamano") == 0) {
                    txt_historial.append(" [sin tamaño");
                } else {
                    txt_historial.append(" [" + data.getExtras().getInt("tamano"));
                }
                // Si no se ha editado mayúsculas/minúsculas no se muestra nada
                // Esto es libre interpretación del enunciado, otras soluciones también
                // son posibles si están razonadas
                if (!data.getExtras().getString("mayusculas").toString().equals("")) {
                    txt_historial.append(", " + data.getExtras().getString("mayusculas"));
                }
                txt_historial.append("]");
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Cargamos la vista del archivo menu_main.xml que hemos editado
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        // Tratamos la selección de elementos del menú
        // En este caso hay una sola opción, pero se deja el esquema
        // para facilitar añadir nuevos elementos al menú

        switch (item.getItemId()) {
            case R.id.menu_limpiar_historial:
                txt_historial.setText("");
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}