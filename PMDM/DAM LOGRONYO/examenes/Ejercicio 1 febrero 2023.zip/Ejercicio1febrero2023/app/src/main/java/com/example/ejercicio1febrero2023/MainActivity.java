package com.example.ejercicio1febrero2023;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    RadioGroup rdg_opciones;
    EditText edt_entrada_salida;

    // Variables globales para representar estado actual
    String base_actual = "DECIMAL";
    int base_num_actual = 10;

    private static final int CUADRO_DIALOGO_FUERA_RANGO = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rdg_opciones = (RadioGroup) findViewById(R.id.rdg_opciones);
        edt_entrada_salida = (EditText) findViewById(R.id.edt_entrada_salida);

        // Listener del grupo de opciones
        rdg_opciones.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch (checkedId) {
                    case R.id.rdb_binario:
                        cambiar_a_base("BINARIO", 2);
                        break;
                    case R.id.rdb_octal:
                        cambiar_a_base("OCTAL", 8);
                        break;
                    case R.id.rdb_decimal:
                        cambiar_a_base("DECIMAL", 10);
                        break;
                    case R.id.rdb_hexadecimal:
                        cambiar_a_base("HEXADECIMAL", 16);
                        break;
                    default:
                        break;
                }

            }
        });

    }

    // Método para realizar la conversión del número de la base actual a la base destino
    // La base actual es una variable global, la base destino es un parámetro de entrada (String e int)
    private void cambiar_a_base(String base_destino, int base_num_destino) {

        // Si el campo está en blanco no se realiza conversión
        if (edt_entrada_salida.getText().toString().equals("")) {
            // Este Toast es no se pedía en el enunciado, pero se muestra con el propósito de aclarar este caso
            Toast.makeText(getApplicationContext(), "Campo en blanco", Toast.LENGTH_LONG).show();
        } else {
            String numero = edt_entrada_salida.getText().toString();
            //comprobamos si tiene prefijo y lo quitamos
            if (numero.startsWith("0b")) {
                base_actual = "BINARIO";
                base_num_actual = 2;
                numero = numero.substring(2, numero.length());
            } else if (numero.startsWith("0o")) {
                base_actual = "OCTAL";
                base_num_actual = 8;
                numero = numero.substring(2, numero.length());
            } else if (numero.startsWith("0d")) {
                base_actual = "DECIMAL";
                base_num_actual = 10;
                numero = numero.substring(2, numero.length());
            } else if (numero.contains("0x")) {
                base_actual = "HEXADECIMAL";
                base_num_actual = 16;
                numero = numero.substring(2, numero.length());
            }

            // Inicializamos variables locales
            int decimal = 0;
            String salida="";
            try {
                // Paso 1: convertimos a decimal como paso intermedio
                decimal = Integer.parseInt(numero, base_num_actual);

                // Si el número no está entre 0 y 255 mostramos el cuadro de diálogo
                if (decimal < 0 || decimal > 255) {
                    showDialog(CUADRO_DIALOGO_FUERA_RANGO);

                } else {
                    // Paso 2: convertimos a base destino desde decimal
                    switch (base_num_destino) {
                        case 2:
                            salida = "0b" + Integer.toBinaryString(decimal);
                            break;
                        case 8:
                            salida = "0o" + Integer.toOctalString(decimal);
                            break;
                        case 10:
                            salida = "0d" + Integer.toString(decimal);
                            break;
                        case 16:
                            salida = "0x" + Integer.toHexString(decimal).toUpperCase();
                            break;
                    }

                    //Mostramos el Toast que nos piden en el enunciado
                    Toast.makeText(getApplicationContext(),
                                    getResources().getString(R.string.mensaje_toast, numero, base_actual, base_destino),
                                    Toast.LENGTH_LONG)
                            .show();
                }
            } catch (NumberFormatException e) {
                // En el caso de que en la entrada haya un dato que no sea válido para la conversión, se lanza esta excepción
                // P.ej. si introducimos el número A9 (hexadecimal) estando seleccionada la opción 'octal'
                // Este Toast no se pedía en el enunciado, pero se muestra con el propósito de aclarar este caso
                Toast.makeText(getApplicationContext(), "El número " + decimal + " no está en base " + base_num_actual, Toast.LENGTH_LONG).show();
            }
            //Mostramos el resultado
            edt_entrada_salida.setText(salida);
        }
        //Actualizamos el estado
        base_actual = base_destino;
        base_num_actual = base_num_destino;
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        Dialog dialogo = null;
        switch (id) {
            case 1:
                dialogo = crear_dialogo_fuera_rango();
                break;
            default:
                dialogo = null;
                break;
        }
        return dialogo;
    }

    // Método para crear el cuadro de diálogo
    private Dialog crear_dialogo_fuera_rango() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        // Construimos el cuadro de diálogo y añadimos
        // título, mensaje y botón positivo con su listener
        builder.setTitle(R.string.dialogo_fuera_rango_titulo)
                .setMessage(R.string.dialogo_fuera_rango_mensaje)
                .setPositiveButton(R.string.dialogo_fuera_rango_texto_boton, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Se cierra el cuadro de diálogo
                        dialog.cancel();
                    }
                });
        return builder.create();
    }
}