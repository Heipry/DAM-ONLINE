package com.cidead.pmdm.tarea5discos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    ImageView ivSatellite;
    ImageView ivCecilia;
    ImageView ivZiggy;
    ImageView ivCandy;
    int id; //Esta variable es muy importante ya que nos ayudará a determinar el View (en este caso ImageView) sobre el cual hemos lanzado su menu contextual

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ivSatellite=(ImageView)findViewById(R.id.ivSatellite);
        ivCecilia=(ImageView)findViewById(R.id.ivCecilia);
        ivZiggy=(ImageView)findViewById(R.id.ivZiggy);
        ivCandy=(ImageView)findViewById(R.id.ivCandy);

        registerForContextMenu(ivSatellite); //Asociamos el menú contextual al control EditText
        registerForContextMenu(ivCecilia); //Asociamos el menú contextual al control EditText
        registerForContextMenu(ivZiggy); //Asociamos el menú contextual al control EditText
        registerForContextMenu(ivCandy); //Asociamos el menú contextual al control EditText
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menucontextualopciones, menu);

        id=v.getId(); //Determinamos cual el ImageView sobre el cual se genera el menu contextual

    }

    //@Override
    public boolean onContextItemSelected(MenuItem item) {


        switch (item.getItemId()) {

            case R.id.itemInfo:
                String cadena="";
                if(id==ivSatellite.getId())
                    cadena="Titulo: Satellite Of Love.\nAutor: Lou Reed.\nDisco: Trasnformer.\nAño: 1972";
                if(id==ivZiggy.getId())
                    cadena="Titulo: Ziggy Stardust.\nAutor: David Bowie.\nDisco: The Rise And Fall Of Ziggy Stardust And The Spiders From Mars.\nAño: 1972";
                if(id==ivCecilia.getId())
                    cadena="Titulo: Cecilia.\nAutor: Simon & Garfunkel.\nDisco: Bridge Over Troubled Water.\nAño: 1970";
                if(id==ivCandy.getId())
                    cadena="Titulo: Candy.\nAutor: Iggy Pop.\nDisco: Brick By Brick.\nAño: 1990";

                Toast t;
                t = Toast.makeText(this, cadena, Toast.LENGTH_LONG);
                t.show();
                break;


            case R.id.itemIrWeb:
                Intent i;
                if(id==ivSatellite.getId()) {
                    i = new Intent("android.intent.action.VIEW", Uri.parse("https://en.wikipedia.org/wiki/Satellite_of_Love"));
                    startActivity(i);
                }
                if(id==ivCecilia.getId()) {
                    i = new Intent("android.intent.action.VIEW", Uri.parse("https://en.wikipedia.org/wiki/Cecilia_(Simon_%26_Garfunkel_song)"));
                    startActivity(i);
                }
                if(id==ivZiggy.getId()) {
                    i = new Intent("android.intent.action.VIEW", Uri.parse("https://en.wikipedia.org/wiki/Ziggy_Stardust_(song)"));
                    startActivity(i);
                }
                if(id==ivCandy.getId()) {
                    i = new Intent("android.intent.action.VIEW", Uri.parse("https://en.wikipedia.org/wiki/Candy_(Iggy_Pop_song)"));
                    startActivity(i);
                }

                break;
        }
        return true;
    }
}