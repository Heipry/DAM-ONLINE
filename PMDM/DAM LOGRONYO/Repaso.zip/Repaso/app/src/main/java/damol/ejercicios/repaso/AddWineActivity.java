package damol.ejercicios.repaso;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class AddWineActivity extends AppCompatActivity {

    EditText edt_nombre, edt_bodega;
    RadioGroup rdg_tipo;
    TextView txt_cosecha;
    SeekBar skb_cosecha;
    Button btn_insertar, btn_ultimo, btn_volver;

    SharedPreferences preferencias;
    static final String WINE_NAME_KEY = "nombre_vino";
    static final String WINERY_KEY = "bodega";
    static final String WINE_TYPE_KEY = "tipo_vino";
    static final String WINE_YEAR_KEY = "año_cosecha";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_wine);

        edt_nombre = (EditText) findViewById(R.id.edt_name);
        edt_bodega = (EditText) findViewById(R.id.edt_winery);
        rdg_tipo = (RadioGroup) findViewById(R.id.rdg_type);
        txt_cosecha = (TextView) findViewById(R.id.txt_year);
        skb_cosecha = (SeekBar) findViewById(R.id.skb_year);
        btn_insertar = (Button) findViewById(R.id.btn_insert);
        btn_ultimo = (Button) findViewById(R.id.btn_last);
        btn_volver = (Button) findViewById(R.id.btn_back);

        btn_volver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        skb_cosecha.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int cosecha = 1900 + progress;
                txt_cosecha.setText("Añada: " + cosecha);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        btn_ultimo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Leemos preferencias y, de no haberlas, establecemos valores por defecto
                preferencias = getPreferences(MODE_PRIVATE);
                String nombre = preferencias.getString(WINE_NAME_KEY, "");
                String bodega = preferencias.getString(WINERY_KEY, "");
                String tipo = preferencias.getString(WINE_TYPE_KEY, "");
                int cosecha = preferencias.getInt(WINE_YEAR_KEY, 1900);

                //Establecemos valores en los controles para mostrarlos
                edt_nombre.setText(nombre);
                edt_bodega.setText(bodega);
                switch (tipo) {
                    case "Tinto":
                        rdg_tipo.check(R.id.rdb_red_wine);
                        break;
                    case "Blanco":
                        rdg_tipo.check(R.id.rdb_white_wine);
                        break;
                    case "Rose":
                        rdg_tipo.check(R.id.rdb_rose_wine);
                        break;
                    default:
                        break;
                }
                skb_cosecha.setProgress(cosecha-1900);
            }
        });

        btn_insertar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Comprobamos si hay algún campo en blanco
                if (edt_nombre.getText().equals("") || edt_bodega.getText().equals("") || rdg_tipo.getCheckedRadioButtonId() == -1) {
                    Toast.makeText(getApplicationContext(), "Hay campos en blanco", Toast.LENGTH_LONG).show();
                } else {
                    //Si no hay campos en blanco,
                    //recogemos los datos introducidos
                    String nombre = edt_nombre.getText().toString();
                    String bodega = edt_bodega.getText().toString();
                    String tipo = "";
                    switch (rdg_tipo.getCheckedRadioButtonId()) {
                        case R.id.rdb_red_wine:
                            tipo = "Tinto";
                            break;
                        case R.id.rdb_white_wine:
                            tipo = "Blanco";
                            break;
                        case R.id.rdb_rose_wine:
                            tipo = "Rosado";
                            break;
                        default:
                            break;
                    }
                    int cosecha = skb_cosecha.getProgress() + 1900;

                    //Insertamos el vino en la BD
                    DBAdapter db = new DBAdapter(getApplicationContext());
                    db.open();
                    db.insertaVino(nombre, bodega, tipo, cosecha);
                    db.close();

                    //Guardamos en preferencias los datos del último vino insertado
                    preferencias = getPreferences(MODE_PRIVATE);
                    SharedPreferences.Editor editor = preferencias.edit();
                    editor.putString(WINE_NAME_KEY, nombre);
                    editor.putString(WINERY_KEY, bodega);
                    editor.putString(WINE_TYPE_KEY, tipo);
                    editor.putInt(WINE_YEAR_KEY, cosecha);
                    editor.commit();

                    //Mostramos Toast
                    Toast.makeText(getApplicationContext(), "Añadido el vino " + nombre + " de la bodega " + bodega + ". Cosecha " + cosecha, Toast.LENGTH_LONG).show();

                    //Limpiamos campos
                    edt_nombre.setText("");
                    edt_bodega.setText("");
                    rdg_tipo.clearCheck();
                    skb_cosecha.setProgress(0);
                }
            }
        });
    }
}