package damol.ejercicios.repaso;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.InputDevice;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class ImportActivity extends AppCompatActivity {

    private static final int READ_BLOCK_SIZE = 100;
    EditText edt_fichero;
    Button btn_importar, btn_volver;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_import);

        edt_fichero = (EditText) findViewById(R.id.edt_import_filename);
        btn_importar = (Button) findViewById(R.id.btn_import);
        btn_volver = (Button) findViewById(R.id.btn_back_from_import);

        btn_volver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btn_importar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Comprobamos que se indica un nombre de fichero
                String fichero = edt_fichero.getText().toString();
                if (fichero.equals("")) {
                    Toast.makeText(getApplicationContext(), "Hay campos en blanco", Toast.LENGTH_LONG).show();
                } else {
                    //Importamos datos del fichero
                    try {
                        importarVinos(fichero);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    //Limpiamos campo
                    edt_fichero.setText("");
                }
            }
        });
    }

    private void importarVinos(String fichero) throws IOException {
        String vinos = leer_archivo(fichero);

        if (vinos.equals("")) {
            Toast.makeText(getApplicationContext(), "Fichero vacío. Acción cancelada", Toast.LENGTH_LONG).show();
        } else {
            DBAdapter db = new DBAdapter(this);
            db.open();
            Cursor c = db.consultaVinos();
            //Utilizamos clase StringTokenizer para extraer campos usando los delimitadores
            //salto de línea y punto y coma
            StringTokenizer lineas = new StringTokenizer(vinos, "\n");
            int count = 0;
            while (lineas.hasMoreElements()) {
                String linea = lineas.nextToken();
                StringTokenizer campos = new StringTokenizer(linea, ";");
                //Leemos id pero lo obviamos
                String id = campos.nextToken();
                String nombre = campos.nextToken();
                String bodega = campos.nextToken();
                String tipo = campos.nextToken();
                int cosecha = Integer.parseInt(campos.nextToken());
                db.insertaVino(nombre, bodega, tipo, cosecha);
                count++;

            }
            Toast.makeText(getApplicationContext(), "Importados " + count + " vinos", Toast.LENGTH_LONG).show();
            c.close();
            db.close();
        }
    }

    private String leer_archivo(String fichero) throws IOException {
        String cadena="";
        FileInputStream fIn = openFileInput(fichero);
        InputStreamReader isr = new InputStreamReader(fIn);

        char[] inputBuffer = new char[READ_BLOCK_SIZE];

        int charRead;
        while ((charRead = isr.read(inputBuffer)) > 0) {
            String readString = String.copyValueOf(inputBuffer, 0, charRead);
            cadena+=readString;
            inputBuffer = new char[READ_BLOCK_SIZE];
        }
        return cadena;
    }
}