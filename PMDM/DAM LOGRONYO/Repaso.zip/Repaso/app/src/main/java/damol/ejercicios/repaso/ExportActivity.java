package damol.ejercicios.repaso;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

public class ExportActivity extends AppCompatActivity {
    EditText edt_fichero;
    Button btn_exportar, btn_volver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_export);

        edt_fichero = (EditText) findViewById(R.id.edt_export_filename);
        btn_exportar = (Button) findViewById(R.id.btn_export);
        btn_volver = (Button) findViewById(R.id.btn_back_from_export);

        btn_volver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btn_exportar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Comprobamos que se indica un nombre de fichero
                String fichero = edt_fichero.getText().toString();
                if (fichero.equals("")) {
                    Toast.makeText(getApplicationContext(), "Hay campos en blanco", Toast.LENGTH_LONG).show();
                } else {
                    //Guardamos datos en el fichero
                    try {
                        exportarVinos(fichero);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    //Limpiamos el campo
                    edt_fichero.setText("");
                }
            }
        });
    }

    private void exportarVinos(String fichero) throws IOException {
        //Cargamos vinos en un cursor
        DBAdapter db = new DBAdapter(this);
        db.open();
        Cursor c = db.consultaVinos();

        //Recorremos el cursor y concatenamos en un String los campos separados por ';'
        //añadiendo un salto de línea entre vino y vino
        String cadena = "";

        if (c.moveToFirst()) {
            do {
                for (int i=0; i<c.getColumnCount(); i++) {
                    cadena+= c.getString(i).toString() + ";";
                }
                cadena+="\n";
            } while (c.moveToNext());
        } else {
            Toast.makeText(getApplicationContext(), "No hay vinos que exportar", Toast.LENGTH_LONG).show();
        }
        //Escribimos el String en el fichero
        if (!cadena.equals("")) {
            FileOutputStream fOut = openFileOutput(fichero, MODE_PRIVATE);
            OutputStreamWriter osw = new OutputStreamWriter(fOut);

            osw.write(cadena);
            osw.flush();
            osw.close();
            Toast.makeText(getApplicationContext(), "Vinos exportardos al archivo " +  fichero, Toast.LENGTH_LONG).show();
        }

        c.close();
        db.close();
    }
}