package damol.ejercicios.repaso;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    ListView lista_vinos;

    private static final int CUADRO_BORRAR_VINOS = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lista_vinos = (ListView) findViewById(R.id.list_wines);
    }

    @Override
    protected void onResume() {
        super.onResume();
        mostrarVinos();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        Intent intent = new Intent();
        switch (item.getItemId()) {
            case R.id.menu_add_wine:
                intent = new Intent(MainActivity.this, AddWineActivity.class);
                startActivity(intent);
                return true;
            case R.id.menu_export:
                intent = new Intent(MainActivity.this, ExportActivity.class);
                startActivity(intent);
                return true;
            case R.id.menu_import:
                intent = new Intent(MainActivity.this, ImportActivity.class);
                startActivity(intent);
                return true;
            case R.id.menu_delete:
                showDialog(CUADRO_BORRAR_VINOS);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        Dialog dialog = null;
        //Utilizamos un switch para poder añadir más cuadros de diálogo si los necesitamos en el futuro
        switch (id) {
            case CUADRO_BORRAR_VINOS:
                dialog = crearDialogoBorrarVinos();
                break;
        }
        return dialog;
    }

    private Dialog crearDialogoBorrarVinos() {
        AlertDialog.Builder dialogbuilder = new AlertDialog.Builder(this);
        dialogbuilder.setTitle("Borrar vinos")
                .setMessage("Esto borrará todos los datos de la vinoteca. La acción no puede deshacerse. ¿Desea continuar?")
                .setPositiveButton("Continuar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        borrarVinos();
                        //Hay que forzar refresco lista vinos porque no se pasa por onResume al cerrar el cuadro de diálogo
                        mostrarVinos();
                    }
                })
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(), "Acción cancelada", Toast.LENGTH_LONG).show();
                        mostrarVinos();
                        dialog.cancel();
                    }
                });
        return dialogbuilder.create();
    }

    private void borrarVinos() {
        //Cargamos en un cursor la BD
        DBAdapter db = new DBAdapter(this);
        db.open();
        Cursor c = db.consultaVinos();
        //Recorremos el cursor y borramos vinos de la BD
        if (c.moveToFirst()) {
            do {
                //consulto id del vino actual y lo borro
                int id = c.getInt(0);
                db.borraVino(id);
            } while (c.moveToNext());
        } else {
            Toast.makeText(getApplicationContext(), "No hay vinos que borrar", Toast.LENGTH_LONG).show();
        }
        c.close();
        db.close();
    }

    private void mostrarVinos() {
        DBAdapter db = new DBAdapter(this);
        db.open();
        Cursor c = db.consultaVinos();
        //Utilizamos una matriz y un adaptador como se indica en el enunciado
        //para poder cargar elementos
        List<String> elementos = new ArrayList<>();
        ArrayAdapter<String> adaptador = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, elementos);
        //Los recorremos desde el último para que aparezcan el listview en el mismo orden
        //Si queremos en orden inverso cambiamos moveToLast por moveToFirst
        //y moveToPrevious por moveToNext
        if (c.moveToLast()) {
            do {
                elementos.add(0, c.getString(1) + " - " + c.getString(2) + " (" + c.getString(3) + " " + c.getInt(4) + ")");
            } while (c.moveToPrevious());
            //comprobamos numero de vinos
            int numVinos = c.getCount();
            Toast.makeText(getApplicationContext(), "Hay " + numVinos + " vinos en la vinoteca", Toast.LENGTH_LONG).show();
        } else {
            //Si no hay vinos mostramos un Toast
            Toast.makeText(getApplicationContext(), "No hay vinos en la vinoteca. Para añadir vinos haz clic en el menú", Toast.LENGTH_SHORT).show();
        }
        //Incluimos los vinos en el listview
        lista_vinos.setAdapter(adaptador);

        c.close();
        db.close();
    }

}