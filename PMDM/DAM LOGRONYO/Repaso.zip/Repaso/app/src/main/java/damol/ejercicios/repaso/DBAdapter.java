package damol.ejercicios.repaso;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DBAdapter {
    public static final String CLAVE_ID = "id";
    public static final String CLAVE_NOMBRE = "name";
    public static final String CLAVE_BODEGA = "winery";
    public static final String CLAVE_TIPO = "wineType";
    public static final String CLAVE_COSECHA = "year";

    private static final String TAG = "DBAdapter";

    private static final String BBDD_NOMBRE = "vinoteca";
    private static final String BBDD_TABLA = "vinos";
    private static final int BBDD_VERSION = 1;

    private static final String BBDD_CREAR =
            "CREATE TABLE " + BBDD_TABLA + " (" + CLAVE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + CLAVE_NOMBRE + " TEXT NOT NULL, " + CLAVE_BODEGA + " TEXT NOT NULL, " + CLAVE_TIPO + " TEXT NOT NULL, " + CLAVE_COSECHA + " INTEGER NOT NULL);";

    private final Context context;

    private DatabaseHelper DBHelper;
    private SQLiteDatabase db;

    public DBAdapter(Context ctx)
    {
        this.context = ctx;
        DBHelper = new DatabaseHelper(context);
    }

    private static class DatabaseHelper extends SQLiteOpenHelper
    {
        DatabaseHelper(Context context)
        {
            super(context, BBDD_NOMBRE, null, BBDD_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db)
        {
            try {
                db.execSQL(BBDD_CREAR);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
        {
            Log.w(TAG, "Actualizando versión de " + oldVersion + " a "
                    + newVersion + ", se borrarán todos los datos");
            db.execSQL("DROP TABLE IF EXISTS " + BBDD_TABLA);
            onCreate(db);
        }
    }


    public DBAdapter open() throws SQLException
    {
        db = DBHelper.getWritableDatabase();
        return this;
    }


    public void close()
    {
        DBHelper.close();
    }


    public long insertaVino(String nombre, String bodega, String tipo, int cosecha) {
        ContentValues initialValues = new ContentValues();
        initialValues.put(CLAVE_NOMBRE, nombre);
        initialValues.put(CLAVE_BODEGA, bodega);
        initialValues.put(CLAVE_TIPO, tipo);
        initialValues.put(CLAVE_COSECHA, cosecha);


        return db.insert(BBDD_TABLA, null, initialValues);
    }

    public boolean borraVino(long id_fila)
    {
        return db.delete(BBDD_TABLA, CLAVE_ID + "=" + id_fila, null) > 0;
    }

    public Cursor consultaVinos()
    {
        return db.query(BBDD_TABLA, new String[] {CLAVE_ID, CLAVE_NOMBRE, CLAVE_BODEGA, CLAVE_TIPO, CLAVE_COSECHA},
                null, null, null, null, null);
    }

    public Cursor consultaVino(long id_fila) throws SQLException
    {
        Cursor mCursor =
                db.query(true, BBDD_TABLA, new String[] {CLAVE_ID, CLAVE_NOMBRE, CLAVE_BODEGA, CLAVE_TIPO, CLAVE_COSECHA},
                        CLAVE_ID + "=" + id_fila, null,
                        null, null, null, null);
        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        return mCursor;
    }


}