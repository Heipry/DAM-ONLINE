/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tutorialslick;

import java.io.File;
import org.lwjgl.LWJGLUtil;
import org.newdawn.slick.*;
import org.newdawn.slick.Input.*;
import org.newdawn.slick.tiled.*;

/**
 * Proyecto vac�o con Slick
 * 
 * @author lrlopez
 */
public class TutorialSlick extends BasicGame {

    private TiledMap mapa;
    private float despX, despY;
    private float jugadorX, jugadorY;
    private Animation jugador;
   // private TiledMap mapa;
   //  private float despX, despY;
   //  private float guerreroX, guerreroY;
      private SpriteSheet cuadros;
   //   private Animation jugador;
      private Animation jugadorArriba;
      private Animation jugadorDerecha;
      private Animation jugadorAbajo;
      private Animation jugadorIzquierda;
      private int mapaWidth, mapaHeight;

    public TutorialSlick(String name) {
        super(name);
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.setProperty("org.lwjgl.librarypath", new File(new File(System.getProperty("user.dir"), "native"), LWJGLUtil.getPlatformName()).getAbsolutePath());
        System.setProperty("net.java.games.input.librarypath", System.getProperty("org.lwjgl.librarypath"));
        try {
            AppGameContainer container = new AppGameContainer(new TutorialSlick("PMDM - Proyecto Slick"));
            container.setDisplayMode(800, 600, false);
            container.setTargetFrameRate(60);
            container.setVSync(true);
            container.start();
        } catch (SlickException e) {
        }
    }

    @Override
    public void init(GameContainer container) throws SlickException {
      mapa = new TiledMap("data/mapatutorial.tmx", "data");

      cuadros = new SpriteSheet("data/mosquetero.png",50,65);

      jugadorArriba = new Animation(cuadros, 0, 1, 8, 1, true, 50, false);
      jugadorDerecha= new Animation(cuadros, 0, 3, 8, 3, true, 50, false);
      jugadorAbajo  = new Animation(cuadros, 0, 0, 8, 0, true, 50, false);
      jugadorIzquierda
                    = new Animation(cuadros, 0, 2, 8, 2, true, 50, false);
      jugador = jugadorAbajo;
     despX = 0;
     despY = 0;
     jugadorX = 400;
     jugadorY = 300;
     mapaWidth = mapa.getWidth()*mapa.getTileWidth();
     mapaHeight = mapa.getHeight()*mapa.getTileHeight();
    }

    @Override
    public void update(GameContainer gc, int delta) throws SlickException {
     Input entrada = gc.getInput();
     if (entrada.isKeyDown(Input.KEY_DOWN)) {     // Tecla abajo
           jugadorY += delta*0.1f;
          jugador = jugadorAbajo;
            jugador.update(delta);
      }
      if (entrada.isKeyDown(Input.KEY_UP)) {     // Tecla arriba
           jugadorY -= delta*0.1f;
          jugador = jugadorArriba;
            jugador.update(delta);
      }
      if (entrada.isKeyDown(Input.KEY_RIGHT)) {     // Tecla derecha
            jugadorX += delta*0.1f;
          jugador = jugadorDerecha;
            jugador.update(delta);
      }
      if (entrada.isKeyDown(Input.KEY_LEFT)) {     // Tecla izquierda
           jugadorX -= delta*0.1f;
          jugador = jugadorIzquierda;
            jugador.update(delta);
      }
      despX = -(jugadorX - gc.getWidth() / 2);
      despY = -(jugadorY - gc.getHeight() / 2);
      
      if (despX < (gc.getWidth() - mapaWidth)) {
           despX = gc.getWidth() - mapaWidth;
      }
      if (despX > 0) {
            despX = 0;
      }
     if (despY < (gc.getHeight() - mapaHeight)) {
           despY = gc.getHeight() - mapaHeight;
      }
     if (despY > 0) {
           despY = 0;
     }
}

    @Override
    public void render(GameContainer container, Graphics g) throws SlickException {
        g.translate(despX, despY);
        mapa.render(0,0);
        jugador.draw(jugadorX, jugadorY);
        //mapa.render(0,0);
    }

}