/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package proyectoslick;

/**
 *
 * @author Fernando Arnedo Ayensa
 */
import java.io.File;
import org.lwjgl.LWJGLUtil;
import org.newdawn.slick.*;
import org.newdawn.slick.Input.*;
import org.newdawn.slick.tiled.*;

/**
 * Proyecto vac�o con Slick
 *
 * @author lrlopez
 */
public class ProyectoSlick extends BasicGame {

    public ProyectoSlick(String name) {
        super(name);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.setProperty("org.lwjgl.librarypath", new File(new File(System.getProperty("user.dir"), "native"), LWJGLUtil.getPlatformName()).getAbsolutePath());
        System.setProperty("net.java.games.input.librarypath", System.getProperty("org.lwjgl.librarypath"));
        try {
            AppGameContainer container = new AppGameContainer(new ProyectoSlick("PMDM - Proyecto Slick"));
            container.setDisplayMode(800, 600, false);
            container.setTargetFrameRate(60);
            container.setVSync(true);
            container.start();
        } catch (SlickException e) {
        }
    }

    @Override
    public void init(GameContainer container) throws SlickException {
    }

    @Override
    public void update(GameContainer gc, int delta) throws SlickException {
    }

    @Override
    public void render(GameContainer gc, Graphics g) throws SlickException {
    }

}