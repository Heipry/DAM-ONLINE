package midletAtlas;


/**
 * Clase para el manejo de la informaci�n correspondiente a un
 * pais de un continente que se mostrar� en la aplicaci�n midletAtlas.
 *
 * @author 
 */

public class Pais {
    private String nombre;
    private String rutaImagen;
    
    /**
     * Constructor de la clase que inicializa todos los datos a null
     */
    public Pais() {
        this.nombre = null;
        this.rutaImagen = null;
    }

    /**
     * Constructor de la clase que inicializa los datos del pa�s con los
     * valores de los par�metros pasados
     * @param nombre Valor para asignar al nombre del pais
     * @param rutaImagen  Valor para asignar a la ruta en la que se encuentra
     * la imagen del pa�s
     */
    public Pais(String nombre, String rutaImagen) {
        this.nombre = nombre;
        this.rutaImagen = rutaImagen;
    }

    /**
     * @return nombre del pa�s
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre valor para asignar al nombre del pa�s
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return ruta en la que se encuentra la imagen del pa�s
     */
    public String getRutaImagen() {
        return rutaImagen;
    }

    
    /**
     * @param rutaImagen ruta en la que se encuentra la imagen del pa�s 
     */
    public void setRutaImagen(String rutaImagen) {
        this.rutaImagen = rutaImagen;
    }

}
