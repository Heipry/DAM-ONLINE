package midletAtlas;


import java.util.Vector;

/**
 * Clase que nos facilitar� el manejo de la informaci�n correspondiente a un
 * continente que se mostrar�n en la aplicaci�n midletAtlas.
 * 
 * @version 1.0
 * @author 
 */
public class Continente {
    private String nombre;
    private String descripcion;
    private String rutaImagen;
    private Vector paises = new Vector();
    
    /**
     * Construcctor sin par�metros, se inicializan todas las variables a null
     */
    public Continente() {
        this.nombre = null;
        this.descripcion = null;
        this.rutaImagen = null;
        this.paises = null;
    }
    
    /**
     * Constructor que nos permite la creaci�n de un objeto continente
     * inicializando todos sus datos, excepto los paises que se mostrar�n
     * 
     * @param nombre Valor para asignar al nombre del continente
     * @param descripcion Valor para asign a la descripci�n del continente
     * @param rutaImagen Valor para asignar a la ruta del continente 
     */
    public Continente(String nombre, String descripcion, String rutaImagen) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.rutaImagen = rutaImagen;
    }
    
    /**
     * Funci�n que agrega un pais a la lista de paises del continente
     * @param pais Pais a agregar en la lista
     * @return Vector con todos los paises del continente
     */
    public Vector agregarPais(Pais pais) {
        paises.addElement(pais);
        return paises;
    }

    /**
     * @return el nombre del continente
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre el nombre para asignar al continente
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return la descripcion del continente
     */
    public String getDescripcion() {
        return descripcion;
    }

    /**
     * @param descripcion la descripcion a asignar al continente
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    /**
     * @return la ruta donde se encuentra almacenada la imagen del continente
     */
    public String getRutaImagen() {
        return rutaImagen;
    }

    /**
     * @param rutaImagen valor para asignar a la ruta donde se encuentra 
     * almacenada la imagen del continente
     */
    public void setRutaImagen(String rutaImagen) {
        this.rutaImagen = rutaImagen;
    }

    /**
     * @return Vector de paises que representa la lista de Paises del continente
     */
    public Vector getPaises() {
        return paises;
    }

    /**
     * @return El n�mero de paises que contiene la lista de continentes
     */
    public int getNumeroPaises() {
        return paises.size();
    }
    
    /**
     * Devuelve el pa�s que se encuentra en la posici�n "indice" de la lista
     * de paises del continente.
     * @param indice posici�n en la lista de paises del pa�s que deseamos 
     * recuperar
     * @return El pa�s que deseamos recupera de la lista de paises del continente
     */
    public Pais getPaisAt(int indice) {
        return (Pais)paises.elementAt(indice);
    }
}
