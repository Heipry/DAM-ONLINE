package midletAtlas;

import java.io.IOException;
import java.io.InputStream;
import java.util.Vector;
import javax.microedition.lcdui.*;
import javax.microedition.midlet.MIDlet;

/**
 * Aplicaci�n correspondiente a la Tarea 1 del m�dulo de Programaci�n de 
 * Dispositivos M�viles del ciclo Desarrollo de Aplicaciones Multiplataforma
 *<br>
 * 
 *  una pantalla en la que se puede seleccionar un continente (Europa, Asia, �frica, Am�rica, Ocean�a).<br>
 *  Al seleccionar uno de esos elementos se abre una nueva pantalla que contiene:<br>
 *      <blockquote> - El nombre del continente.<br>
 *       - Una imagen del continente (mapa).<br>
 *       - Una peque�a descripci�n del continente.<br>
 *       - Un grupo de selecci�n m�ltiple con pa�ses del continente.<br></blockquote>
 *  Mediante el comandando "Volver" se vuelve a la lista de continentes.<br>
 *  Mediante el comando "Ver pa�ses" se accede una nueva pantalla que muestra:<br>
 *      <blockquote> - Nombre del continente.<br>
 *       - Im�gen de los pa�ses seleccionados (mapas) junto con sus nombres.<br></blockquote>
 *  Si no hay ning�n pa�s seleccionado se m unuestra una pantalla de alerta 
 *  indicando que no se ha seleccionado ning�n pa�s.<br>
 *  Mediante el comando "Volver" podemos volver a la pantalla anterior.<br><br>
 * 
 *  Adem�s hay una pantalla de cr�ditos (nombre del autor, fecha, etc.), 
 *  una pantalla de instrucciones (indicando para qu� sirve la aplicaci�n y 
 *  c�mo puede usarse) y una pantalla de presentaci�n inicial con una imagen.<br><br>
 * 
 * Para el manejo de la informaci�n referente a los continentes y paises se
 * han implementados las correspondientes clases <b>Continente</b> y <b>Pa�s</b>
 * 
 * Noviembre 2012
 * 
 * @author 
 * @see Pais
 * @see Continente
 */
public class midletAtlas extends MIDlet implements CommandListener {
    // Ruta en la que se encuentran las im�genes de la aplicaci�n
    private static final String RUTA_IMAGENES = "/imagenes/";
    
    // Ruta en la que se encuentran los datos de la aplicaci�n
    private static final String ARCHIVO_DATOS = "/datos/datos.txt";
    
    // Ruta en la que se encuentra el fichero con el texto de los cr�ditos
    private static final String ARCHIVO_CREDITOS ="/datos/creditos.txt";
    
    // Ruta en la que se encuentra el fichero con el texto de las istrucciones
    private static final String ARCHIVO_INSTRUCCIONES ="/datos/instrucciones.txt";
    
     // Array de objetos continente para almacenar los datos de cada uno de ellos
    private Continente[] continentes = new Continente[5];
    
    // List para mostrar los continentes en la pantalla principal
    private List listaContinentes;
   
    // Formularios para las pantallas de segundo y tercer nivel
    private Form formContinente, formPaises;
    
    // Formularios Splash, Instrucciones, y Cr�ditos
    private Form formSplash, formInstrucciones, formCreditos;
    
    // Lista de selecci�n de los paises de un continente
    private ChoiceGroup listaPaises;
    
    // Alerta para mostrar en caso de no seleccionar ning�n pais
    private Alert alerta;
    
    // Display de la aplicaci�n
    private Display display;
    
    // Displayable para guardar el screen anterior
    private Displayable displayableAnterior;          
    
    // Indice del continente actualmente seleccionado
    private int indiceContinente;
    
    // Array con los flags de selecci�n de los paises de un continente
    private boolean[] seleccionPaises;
    
    // Comandos para controlar la navegaci�n por las diferentes pantallas
    private Command cmdTerminar;
    private Command cmdVolver;
    private Command cmdVerPaises;
    private Command cmdOK;
    private Command cmdCreditos;
    private Command cmdInstrucciones;
    
    // Variables String para los textos de la aplicaci�n
    private String strVolver, strVer, strCredito, strInstrucciones;
    private String strContinentes, strAtencion, strSinSeleccionPaises;
    private String strAlgunosPaises, strTerminar, strOK;
    private String strLeyendoDatos, strCreandoComandos, strCreandoPantallas;
    private String strTextoCreditos, strTextoInstrucciones;
     
        
    /**
     * Constructor de la clase de la aplicaci�n.<br>
     * Ejecutamos las acciones que se realizar�an por defecto al iniciarse la 
     * aplicaci�n, y seguidamente leemos los datos del fichero de datos, creamos
     * los diferentes comandos de la aplicaci�n, as� como la pantalla del primer
     * nivel (que permanecer� invariable) y la mostramos.
     */
    public midletAtlas(){
        super();
        // cargamos la imagen para la pantalla splash
        Image img;// = null;
        ImageItem imgItem=null;
        try {
             img = Image.createImage(RUTA_IMAGENES + "mapamundi.png");
             imgItem = new ImageItem("", 
                     img, 
                     Item.LAYOUT_CENTER|Item.LAYOUT_NEWLINE_AFTER, 
                     "");
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        // creamos el texto a mostran en pantalla splash
        String strTextoItemSplash = "";
        StringItem strItem = new StringItem("", strTextoItemSplash);
        // creamos el formulario y lo mostramos
        formSplash = new Form("midletAtlas");
        formSplash.append(imgItem);
        formSplash.append(strItem);
        display=Display.getDisplay(this);
        display.setCurrent(formSplash);
        // leemos los datos de la aplicaci�n y modificamos el texto mostrado
        // en la pantalla splash miestras se van procesando.
        // Se incluye un retardo de 1,5 segundos para hacer mas patente el efecto
        procesarArchivoDatos();
        strItem.setText(strLeyendoDatos);
        try {
            Thread.sleep(1500);
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        strItem.setText(strCreandoComandos);    
        crearComandos();
        try {
            Thread.sleep(1500);
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        strItem.setText(strCreandoPantallas);
        crearFormInstrucciones();
        crearFormCreditos();
        crearMenuPrincipal();    
        crearAlerta();
        try {
            Thread.sleep(1500);
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        display.setCurrent(listaContinentes);
    }

    /**
     * Implementaci�n del m�todo commandAction de la clase CommandListener que se
     * ser� llamado cuando se produzca un evento de comando sobre el Displayable d
     * @param c Comando desencadenante del evento
     * @param d Displayable pantalla sobre la que se ha producido el evento
     */
    public void commandAction(Command c, Displayable d) {
        // Si se produce un evento de selecci�n desde la lista de continentes
        // llamaremos al formulario que muestra los datos del continente seleccionado
        if (c == List.SELECT_COMMAND && d==listaContinentes) {
            indiceContinente = listaContinentes.getSelectedIndex(); 
            crearFormContinente(indiceContinente);
            display.setCurrent(formContinente);
            
        // Si se produce el evento de comando "Volver" y la pantalla actual es
        // la que muestra los datos de un continente, hacemos visible la 
        // pantalla inicial
        } else if (c == cmdVolver && d == formContinente) {
            display.setCurrent(listaContinentes);
        // Si se produce el evento de comando "Volver" y la pantalla actual es la 
        // que muestra los paises seleccionados de un continente, hacemos visible
        // el formulario que muestra los datos de un continente    
        } else if (c == cmdVolver && d == formPaises) {
            display.setCurrent(formContinente);
        // Si se produce el evento de comamdo "Volver" desde los formularios de
        // Creditos o Instrucciones, mostramos el formulario desde el que fueron
        // llamados
        } else if (c == cmdVolver && (d==formCreditos || d==formInstrucciones)) {
            display.setCurrent(displayableAnterior);  
        // El evento de comando "Ver paises" solo puede producirse desde el formulario
        // que muestra los datos de un continente, por lo que mostraremos el formulario
        // con las im�genes de los paises seleccionados o el mensaje de alerta
        // si no se seleccion� ning�n pais.
        } else if (c == cmdVerPaises) {
                if (crearFormPaises(indiceContinente)) 
                    display.setCurrent(formPaises);
                else
                    display.setCurrent(alerta, d);
        // Los formularios de Cr�ditos e Instrucciones pueden llamarse desde
        // varias pantallas diferentes, por lo que debemos recordar desde que
        // pantalla fueron llamados para recuperarla cuando se seleccione cmdVolver
        }  else if (c == cmdCreditos) {
            displayableAnterior = d;
            display.setCurrent(formCreditos);   
        } else if (c == cmdInstrucciones) {
            displayableAnterior = d;
            display.setCurrent(formInstrucciones);
        // El evento de comando "Terminar" solo puede producirse desde la pantalla
        // inicial, por lo que salimos de la aplicaci�n.
        } else if (c == cmdTerminar) {
          Display.getDisplay(this).setCurrent(null);
          destroyApp(true);
          notifyDestroyed();  
        }
    }
    
    
    public void startApp() { 
    }
    
    public void pauseApp() {
    }
    
    public void destroyApp(boolean unconditional) {
    }
     
       
    /**
     * Crea los diferentes comandos que utilizar� la aplicaci�n en los formularios
     */
    private void crearComandos() {
        cmdTerminar = new Command(strTerminar, Command.EXIT, 0);
        cmdVolver = new Command(strVolver, Command.BACK, 0);
	cmdVerPaises = new Command(strVer, Command.SCREEN, 1);
        cmdOK = new Command(strOK, Command.OK, 0);
        cmdCreditos = new Command(strCredito, Command.SCREEN, 2);
        cmdInstrucciones = new Command(strInstrucciones, Command.SCREEN, 3);
        
    }
    
    /**
     * Crea el formulario inicial de la aplicaci�n, que �nicamente contiene
     * una lista implicita con los nombres de los paises
     */
    private void crearMenuPrincipal() {
        listaContinentes = new List(strContinentes, List.IMPLICIT);
        for(int i=0; i<continentes.length; i++) {
            listaContinentes.insert(i, continentes[i].getNombre(), null);
        }
        listaContinentes.setCommandListener(this);
        listaContinentes.addCommand(cmdTerminar);
        listaContinentes.addCommand(cmdCreditos);
        listaContinentes.addCommand(cmdInstrucciones);
    }
    

    /**
     * Crea el formulario de instrucciones a partir de los datos extraidos
     * del fichero de datos
     */ 
    private void crearFormInstrucciones() {
        Vector texto = split(strTextoInstrucciones, "#");
        String strTitulo = (String)texto.elementAt(0);
        String strContenido = (String)texto.elementAt(1);
        StringItem strItemInstrucciones = new StringItem ("", strContenido);
        formInstrucciones = new Form(strTitulo);
        formInstrucciones.append(strItemInstrucciones);
        formInstrucciones.addCommand(cmdVolver);
        formInstrucciones.setCommandListener(this);
    } 
    
    /**
     * Crea el formulario de cr�ditos a partir de los datos extraidos
     * del fichero de datos
     */
    private void crearFormCreditos() {
        Vector texto = split(strTextoCreditos, "#");
        String strTitulo = (String)texto.elementAt(0);
        String strContenido = (String)texto.elementAt(1);
        StringItem strItemCreditos = new StringItem ("", strContenido);
        formCreditos = new Form(strTitulo);
        formCreditos.append(strItemCreditos);
        formCreditos.addCommand(cmdVolver);
        formCreditos.setCommandListener(this);
    } 
   
   /**
    * Crea la alerta a mostrar en caso de que no se seleccione ning�n pais
    */ 
    private void crearAlerta() {
        alerta = new Alert(strAtencion, this.strSinSeleccionPaises, null, AlertType.INFO);
        alerta.addCommand(cmdOK);
        alerta.setTimeout(4000);
        
    }
    
    
    /**
     * Crea un nuevo formulario para mostrar los datos del continente seleccionado
     * en el men� principal.
     * 
     * @param indice int con el n�mero de continente actualmente seleccionado 
     */	
    private void crearFormContinente(int indice) {
        // Creamos el formulario d�ndole el nombre del continente seleccionado
	formContinente = new Form(continentes[indice].getNombre());
        // Agregamos la imagen del continente al formulario
        try {
            String ruta = RUTA_IMAGENES + continentes[indice].getRutaImagen();
            formContinente.append(Image.createImage(ruta));
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        // Agregamos el texto con la descripci�n del continente
        formContinente.append(continentes[indice].getDescripcion());
        // Creamos y agregamos la lista de selecci�n multiple con los paises
        listaPaises = new ChoiceGroup(strAlgunosPaises + " " + 
                continentes[indice].getNombre(),Choice.MULTIPLE);
        for (int i=0; i<continentes[indice].getNumeroPaises(); i++)
           listaPaises.append(continentes[indice].getPaisAt(i).getNombre(), null);              
        formContinente.append(listaPaises);
        // A�adimos los comandos "Volver" y "Ver Paises" 
        // y ponemos el formulario en escucha.
	formContinente.addCommand (cmdVerPaises);
	formContinente.addCommand (cmdVolver);
        formContinente.addCommand(cmdCreditos);
        formContinente.addCommand(cmdInstrucciones);
        formContinente.setCommandListener(this);
    }
    
   /**
    * Crea un nuevo formulario para mostrar las im�genes de cada uno de los 
    * paises seleccionados en la lista "Algunos paises de ..." del formulario
    * correspondiente al continente actualmente visible.
    * 
    * @param indice int con el n�mero de continente actualmente visible
    * @return True si se ha seleccionado al menos un pa�s en la lista de paise
    * o false si no se ha seleccionado ninguno.
    */
    private boolean crearFormPaises(int indice) {
       //Pais paises[] = continentes[indice].paises;
       // Creamos el formulario con el nombre del continente seleccionado
       formPaises =  new Form(continentes[indice].getNombre()); 
       // Recuperamos el array con los flags de selecci�n de la lista de paises
       seleccionPaises = new boolean[continentes[indice].getNumeroPaises()];
       listaPaises.getSelectedFlags(seleccionPaises);
       // Recorremos el array de flags, a�adiendo la imagen al formulario
       // si el pais est� seleccionado
       boolean bSeleccionado = false;
       for (int i=0; i<continentes[indice].getNumeroPaises(); i++) {
           if (seleccionPaises[i]) {
                bSeleccionado = true;
                try {
                    ImageItem imgItem = new ImageItem(
                            continentes[indice].getPaisAt(i).getNombre(),
                            Image.createImage(RUTA_IMAGENES + continentes[indice].getPaisAt(i).getRutaImagen()),
                            Item.LAYOUT_CENTER,
                            "");
                    formPaises.append(imgItem);
                } catch (IOException ex) {
                        ex.printStackTrace(); 
                } 
           }
       }
       // agregamos el comando "Volver" y a�adimos el formulario a la escucha
       formPaises.addCommand(cmdVolver);
       formPaises.addCommand(cmdCreditos);
       formPaises.addCommand(cmdInstrucciones);
       formPaises.setCommandListener(this);  
       return bSeleccionado;       
    }
    
     /**
     * Lee el contenido del fichero con los datos de la aplicaci�n y lo carga en
     * un String que posteriormente es procesado para extraer cada uno de los datos
     * correspondiente a los diferentes continentes.<br>
     * En el fichero de datos los continentes se separan mediante la cadena 
     * {@literal "<continente>"} y los datos de cada pais mediante el caracter '#'
     * <br>Tras los continentes encontraremos  los literales cuyo comienzo viene
     * marcado mediante la cadena {@literal "<literales>"}.<br>
     * Seguidamente viene el texto con las instrucciones de la aplicaci�n, que
     * comienzan tras la cadena {@literal "<instrucciones>"}.<br>
     * Y finalmente, el texto de la pantalla de cr�ditos que comienza tras la
     * cadena {@literal "<creditos>"}
     */
    private void procesarArchivoDatos() {
        // Leemos el archivo
        String texto = leerArchivoTXT(ARCHIVO_DATOS);
        System.out.println(texto);
        // obtenemos el texto para el formulario de cr�ditos
        Vector strTextoSplit = split(texto, "<creditos>");
        strTextoCreditos = (String)strTextoSplit.elementAt(1);        
        // obtenemos el texto para el formulario de instrucciones
        strTextoSplit = split((String)strTextoSplit.elementAt(0), "<instrucciones>");
        strTextoInstrucciones = (String)strTextoSplit.elementAt(1);
        // obtenemos los datos de los literales y los guardamos en las variables
        strTextoSplit = split((String)strTextoSplit.elementAt(0), "<literales>");
        Vector vectorVar = split((String)strTextoSplit.elementAt(1), "#");
        strTerminar = (String)vectorVar.elementAt(0);
        strVolver = (String)vectorVar.elementAt(1);
        strVer = (String)vectorVar.elementAt(2);
        strOK = (String)vectorVar.elementAt(3);
        strCredito = (String)vectorVar.elementAt(4);
        strInstrucciones = (String)vectorVar.elementAt(5);
        strContinentes = (String)vectorVar.elementAt(6);
        strAtencion = (String)vectorVar.elementAt(7);
        strSinSeleccionPaises = (String)vectorVar.elementAt(8);
        strAlgunosPaises = (String)vectorVar.elementAt(9);
        strLeyendoDatos = (String)vectorVar.elementAt(10);
        strCreandoComandos = (String)vectorVar.elementAt(11);
        strCreandoPantallas = (String)vectorVar.elementAt(12);
        
        // el resto son los datos de los continentes
        String descContinente, nombreContinente="", rutaImagenContinente="", 
                nombrePais="", rutaImagenPais; 
        Continente continente = null;
        // Separamos cada continente
        Vector strContinente = split((String)strTextoSplit.elementAt(0), "<continente>");
        // y para cada continente
        for (int i= 0; i<strContinente.size(); i++) {
            int nPais=0;
            // separamos los diferentes datos del continente
            Vector token = split((String)strContinente.elementAt(i), "#");
            for (int j= 0; j<token.size(); j++) {
                // El primer dato de un continente es su nombre
                if (j==0) 
                   nombreContinente = ((String) token.elementAt(j)).trim();
                // El segundo dato de un continente es la ruta de la imagen del continente
                else if (j==1)
                   rutaImagenContinente = ((String) token.elementAt(j)).trim();
                // El tercer dato de un continente es su descripci�n
                else if (j==2) {
                   descContinente = ((String) token.elementAt(j)).trim(); 
                   continente = new Continente(nombreContinente, descContinente, rutaImagenContinente);
                } 
                // Del cuarto en adelante, los datos corresponden por parejas al
                // nombre y ruta de la imagen de cada pa�s
                else if (j>=3){
                    if (nPais++%2 == 0)
                        nombrePais =((String) token.elementAt(j)).trim();
                    else {
                        rutaImagenPais =((String) token.elementAt(j)).trim();
                        continente.agregarPais(new Pais(nombrePais, rutaImagenPais));
                    }                 
                }
            }
            // asignamos el continente leido a un elemento del array de continentes
            continentes[i] = continente;
        }
    }   
    
    
    /**
     * Funci�n que lee el archivo de texto pasado como par�metro y devuelve su
     * contenido en un String
     * 
     * @param archivo nombre y ruta del archivo de texto a leer
     * @return String con el texto contenido en el fichero
     */
    private String leerArchivoTXT(String archivo){
        InputStream is = getClass().getResourceAsStream(archivo);
        try{
            StringBuffer sb = new StringBuffer();
            int chr;
            // leemos caracteres y los vamos a�adiendo al buffer  hasta llegar
            // al final del fichero, momento en el que devolvemos el contenido
            // del mismo como un String
            while ((chr = is.read()) != -1)
                sb.append((char)chr);
            return sb.toString();
        } catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }
    
    /**
     * Devuelve un vector de strings resultante de partir el string cadena
     * en subcadenas delimitadas por el string separador.<br>
     * Similar a la funci�n Split de la clase String de Java SE y que en Java ME
     * no se encuentra disponible (salvo que el resultado se devuelve en un 
     * vector en lugar de en un array de Strings):
     * 
     * @param cadena String del que se obtienen las subcadenas
     * @param separador Sring que se utiliza para delimitar las subcadenas dentro
     *        de la cadena pasada como par�metro.
     * @return Vector que contiene las subcadenas obtenidas.
     */
    public Vector split(String cadena, String separador){
        Vector items = new Vector();
        // obtenemos la primera ocurrencia del String separador
        int pos = cadena.indexOf(separador);
        // mientra haya subcadenas
        while(pos >= 0){
            // a�adimos  la subcadena al vector
            items.addElement(cadena.substring(0,pos).trim());
            // y acortamos la cadena quitando la subcadena y el separador
            cadena = cadena.substring(pos + separador.length());
            pos = cadena.indexOf(separador);
        }
        items.addElement(cadena);
        return items;
    }
    
}
