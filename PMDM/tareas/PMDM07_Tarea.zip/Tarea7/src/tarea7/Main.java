package tarea7;

import com.jme3.app.SimpleApplication;
import com.jme3.asset.TextureKey;
import com.jme3.asset.plugins.FileLocator;
import com.jme3.audio.AudioNode;
import com.jme3.bullet.BulletAppState;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.input.KeyInput;
import com.jme3.input.MouseInput;
import com.jme3.input.controls.ActionListener;
import com.jme3.input.controls.KeyTrigger;
import com.jme3.input.controls.MouseButtonTrigger;
import com.jme3.light.DirectionalLight;
import com.jme3.material.Material;
import com.jme3.math.ColorRGBA;
import com.jme3.math.Vector2f;
import com.jme3.math.Vector3f;
import com.jme3.renderer.RenderManager;
import com.jme3.renderer.queue.RenderQueue.ShadowMode;
import com.jme3.scene.Geometry;
import com.jme3.scene.shape.Box;
import com.jme3.scene.shape.Cylinder;
import com.jme3.scene.shape.Sphere;
import com.jme3.shadow.BasicShadowRenderer;
import com.jme3.shadow.PssmShadowRenderer;
import com.jme3.texture.Texture;
import com.jme3.texture.Texture.WrapMode;

/**
 * Bolos - Aplicación para la implementación de la tarea 7 de PMDM del ciclo
 * DAM.<br> Modificado por Fernando Arnedo Ayensa <br> Sevilla - Mayo 2013
 *
 * @author Ministerio de Educación. Gobierno de España.
 *
 */
public class Main extends SimpleApplication {

    Geometry sueloGeo;
    Geometry bolaGeo;
    RigidBodyControl bolaFis;
    private BulletAppState bulletAppState;
    private Material matBola, matMadera, matPiedra, matBolo;
    Bolo[] bolo;
    private boolean gravedadActiva;
    private AudioNode sonidoLanzarBola, sonidoFondo;

    /**
     * Clase principal de la aplicación.<br> Inicia la aplicación.
     *
     * @param args Argumentos de la linea de comandos. No se procesan.
     */
    public static void main(String[] args) {
        Main app = new Main();
        app.start();

    }

    /**
     * Método que se ejecuta al iniciar la aplicación.<br> Se inician las
     * variable globales y se crean los diferentes elementos de la escena.
     */
    @Override
    public void simpleInitApp() {
        // ponemos en marcha el motor de físicas
        bulletAppState = new BulletAppState();
        stateManager.attach(bulletAppState);
        // registramos nuestro directorio de assets
        assetManager.registerLocator("assets", FileLocator.class);
        // comenzamos con la gravedad activa
        gravedadActiva = true;
        // Creamos los materiales
        crearMateriales();
        // Creamos el suelo
        crearSuelo();
        // Creamos la pared
        crearPared();
        // Creamos la luz
        crearLuz();
        // Creamos las sombras
        crearSombras();
        // creamos los bolos
        crearBolos();
        // Creamos la bola
        crearBola();
        // creamos las acciones que responden al teclado y al ratón
        crearAcciones();
        // Ponemos camara en posicion inicial
        iniciarCamara();
        // Ponemos el audio
        iniciarAudio();
        // Ponemos un color de fondo azul oscuro
        viewPort.setBackgroundColor(new ColorRGBA(0f, 0f, 0.2f, 0));
    }

    /**
     * Se crea el suelo a partir de una forma cúbica de un material determinado,
     * a la que asociaremos un control de físicas que finalmente añadiremos al
     * control de físicas.<br> Es importante que la geometria del suelo se
     * "hunda" tanto como la altura de la forma. De esta forma conseguiremos que
     * la superficie del suelo coincida con el 0 del eje x.<br> Asimismo es
     * importante que el control físico tenga peso 0 para que sea estático.
     */
    private void crearSuelo() {

        // Para hacer el suelo usaremos estas variables:
        // suelo:       la forma del suelo
        // matMadera:   el material del suelo
        // sueloGeo:    el spatial de tipo geometría que contendrá el suelo
        // sueloFis:   el objeto de control de físicas que está asociado al suelo

        // Creamos una forma de caja de 5 metros de ancho,
        // 10 de largo y 10cm de alto.
        Box suelo = new Box(Vector3f.ZERO, 5f, 0.1f, 10f);

        // ajustamos el tamaño de la textura que le dará aspecto de suelo
        suelo.scaleTextureCoordinates(new Vector2f(6, 3));
        // Creamos un spatial de tipo geometría para asociarlo al suelo
        sueloGeo = new Geometry("Floor", suelo);
        // asignamos el material
        sueloGeo.setMaterial(matMadera);
        // bajamos el suelo 10cm para que el origen esté un poco por encima
        sueloGeo.setLocalTranslation(0, -0.1f, 0);

        sueloGeo.setShadowMode(ShadowMode.Receive);
        // y, finalmente, lo incluimos en el grafo de escena
        rootNode.attachChild(sueloGeo);
        // Crearemos un objeto de control físico para asociarlo al suelo
        // IMPORTANTE: tiene masa 0 para convertirlo en un objeto estático
        RigidBodyControl SueloFis = new RigidBodyControl(0.0f);
        // asociamos el objeto de control a la geometría del suelo
        sueloGeo.addControl(SueloFis);
        // y añadimos el objeto de control al motor de físicas
        bulletAppState.getPhysicsSpace().add(SueloFis);

    }

    /**
     * Se crea la pared del fondo, a partir de un clon del suelo al que le
     * cambiaremos el material.<br> Una vez creada la forma, la enviamos al
     * extremo del suelo en el eje Z y la giramos 90º sobre el eje x para
     * conseguir ponerla vertical.
     *
     */
    private void crearPared() {

        // Para hacer la pared usaremos un clon del suelo       
        Geometry pared_geo = sueloGeo.clone();
        pared_geo.setMaterial(matPiedra);
        // lo desplazamos detrás del suelo e inclinado 90 grados en el eje X
        // para ponerlo en vertical
        pared_geo.setLocalTranslation(0, -0.1f, -10);
        pared_geo.rotate((float) Math.PI / 2.0f, 0f, 0);
        // y, finalmente, lo incluimos en el grafo de escena
        rootNode.attachChild(pared_geo);
        // Crearemos un objeto de control físico para asociarlo a la pared
        // IMPORTANTE: tiene masa 0 para convertirlo en un objeto estático
        RigidBodyControl pared_fis = new RigidBodyControl(0.0f);
        // asociamos el objeto de control a la geometría de la pared
        pared_geo.addControl(pared_fis);
        // y añadimos el objeto de control al motor de físicas
        bulletAppState.getPhysicsSpace().add(pared_fis);
    }

    /**
     * Creamos el punto de luz. Lo situamos sobre el centro de la escena.
     */
    private void crearLuz() {
        // Crearemos una luz direccional que parezca venir de la parte
        // superior derecha del jugador, por detrás.
        DirectionalLight luz = new DirectionalLight();
        // de color blanco y no excesivamente brillante
        luz.setColor(ColorRGBA.White.mult(0.8f));
        // proveniente de la parte superior derecha de la posición inicial
        luz.setDirection(new Vector3f(-1, -1, -1).normalizeLocal());
        // añadir la luz al grafo
        rootNode.addLight(luz);
    }

    /**
     * Creamos el motor de sombras, situándolo de forma similar al punto de luz
     * <br> Se utiliza un solo mapa de sombras de 256 puntos,consiguiendo 
     * sombras realistas con un bajo consumo de recursos.
     */
    private void crearSombras() {
        PssmShadowRenderer pssmSr;
        pssmSr = new PssmShadowRenderer(assetManager, 256, 1);
        pssmSr.setDirection(new Vector3f(-1f, -1f, -1f).normalizeLocal());
        viewPort.addProcessor(pssmSr);
    }

    /**
     * Se crean los diferentes materiales que se utilizarán para construir las
     * geometrías de los objetos.
     */
    private void crearMateriales() {
        // Creamos el material de la pared y el suelo a partir de una textura
        // predefinida, haciendo que se repita por su superficie
        matMadera = new Material(assetManager, "Common/MatDefs/Misc/Unshaded.j3md");
        TextureKey key = new TextureKey("Textures/madera.jpg");
        key.setGenerateMips(true);
        Texture textura = assetManager.loadTexture(key);
        textura.setWrap(WrapMode.Repeat);
        matMadera.setTexture("ColorMap", textura);

        // textura para la pared
        matPiedra = new Material(assetManager, "Common/MatDefs/Misc/Unshaded.j3md");
        key = new TextureKey("Textures/Pond_normal.png");
        key.setGenerateMips(true);
        textura = assetManager.loadTexture(key);
        textura.setWrap(WrapMode.Repeat);
        matPiedra.setTexture("ColorMap", textura);

        // Creamos el material de la bola a partir de una base iluminada y
        // la hacemos de color azul reflectante.
        matBola = new Material(assetManager, "Common/MatDefs/Light/Lighting.j3md");
        matBola.setBoolean("UseMaterialColors", true);
        matBola.setColor("Ambient", ColorRGBA.Cyan);
        matBola.setColor("Diffuse", ColorRGBA.Cyan);
        matBola.setColor("Specular", ColorRGBA.White);
        matBola.setFloat("Shininess", 1);

        // Creamos el material de los bolos a partir del material de la bola
        // y le cambiamos los colores
        matBolo = matBola.clone();
        matBolo.setColor("Ambient", ColorRGBA.White);
        matBolo.setColor("Diffuse", ColorRGBA.White);
        matBolo.setColor("Specular", ColorRGBA.Gray);
    }

    /**
     * Crea la bola que se lanzará.
     */
    private void crearBola() {
        // Creamos una esfera de 40 centímetros de diámetro
        Sphere esfera = new Sphere(32, 32, 0.4f);
        // Asociamps la forma a una geometría nueva
        bolaGeo = new Geometry("bola", esfera);
        // asignamos el material a la geometría
        bolaGeo.setMaterial(matBola);
        bolaGeo.setShadowMode(ShadowMode.CastAndReceive);
        // Objeto de control físico asociado a la bola con un peso de 1Kg.
        bolaFis = new RigidBodyControl(1f);
        // Asociar la geometría de la bola al control físico
        bolaGeo.addControl(bolaFis);
        rootNode.attachChild(bolaGeo);
    }

    /**
     * Crea los bolos, situándolos en su posición correcta.<br>
     * Es muy importante situar el centro de cada cilindro sobre el eje Y a una
     * altura igual a la mitad de la altura del cilindro para que la base
     * descanse justamente sobre el suelo. De otra forma, los bolos saldrán 
     * disparados hacia arriba.<br>
     * El primer bolo se situa en el centro de la escena y a 8 mts desde el jugador
     * Cada fila está distanciada de las contiguas 40 cm.<br>
     * Dentro de cada fila, cada bolo se distancia de los contiguos 30 cm.
     * 
     */
    private void crearBolos() {
        bolo = new Bolo[10];
        // Crear un cilindro de 18 cm de radio y 1,2 metros de altura
        Cylinder figura = new Cylinder(32, 32, 0.18f, 1.2f, true);

        int i = 0;
        //float y = suelo_geo.getLocalTranslation().y;
        for (int fila = 0; fila < 4; fila++) {
            for (int columna = 0; columna < fila + 1; columna++) {
                // creamos las variables para el bolo
                bolo[i] = new Bolo();
                // creamos la geometría del bolo
                bolo[i].geo = new Geometry("bolo" + i, figura);
                // asignamos el material al bolo
                bolo[i].geo.setMaterial(matBolo);
                // activamos sombras sobre el bolo
                bolo[i].geo.setShadowMode(ShadowMode.CastAndReceive);
                // ponemos el bolo en su posición dependiendo de la fila y
                // columna. 
                // IMPORTANTE: el centro del bolo debe estar en el eje "y" 
                // a la mitad de la altura del bolo
                bolo[i].geo.move((float) (-0.3 * fila + 0.6* columna), 0.6f, (float) (-8f - 0.4f * fila));
                // y lo giramos 90º para ponerlo de pie
                bolo[i].geo.rotate((float) Math.PI / 2.0f, 0f, 0f);
                // Objeto de control físico asociado al bolo con un peso de 1 Kg.
                bolo[i].fis = new RigidBodyControl(1f);
                // Agregamos el control a la geometría del bolo
                bolo[i].geo.addControl(bolo[i].fis);
                // Agregamos el bolo al motor de físicas
                bulletAppState.getPhysicsSpace().add(bolo[i].fis);
                // Agregamos el bolo al nodo raiz de la escena
                rootNode.attachChild(bolo[i].geo);
                i++;
            }
        }
    }

    /**
     * Se cargan los sonidos que se utilizarán para que suenen de fondo y 
     * en el disparo de bola. Una vez creados, se pone en reproducción el
     * sonido de fondo.
     */
    private void iniciarAudio() {
        // cargamos el audio que sonará cuando se dispare una bola
        sonidoLanzarBola = new AudioNode(assetManager, "Sounds/disparo_bola.wav", false);
        // el audio sonará en un momento concreto
        sonidoLanzarBola.setLooping(false);
        sonidoLanzarBola.setVolume(2);
        rootNode.attachChild(sonidoLanzarBola);

        // Cargamos el sonido de fondo
        sonidoFondo = new AudioNode(assetManager, "Sounds/sonido_fondo.ogg", false);
        // sonará de forma continua
        sonidoFondo.setLooping(true);
        sonidoFondo.setPositional(true);
        sonidoFondo.setLocalTranslation(Vector3f.ZERO.clone());
        sonidoFondo.setVolume(1);
        rootNode.attachChild(sonidoFondo);
        sonidoFondo.play();
    }

    /**
     * Colocamos la cámara en una posición adecuada para ver la superficie
     * del suelo y mirando hacia ella.
     */
    private void iniciarCamara() {
        cam.setLocation(new Vector3f(0, 4f, 6f));
        cam.lookAt(new Vector3f(0, 2, 0), Vector3f.UNIT_Y);
    }
    
    
    /**
     * Se crean las acciones asociadas a los controles de interface del usuario.
     */
    private void crearAcciones() {
        // creamos la acción de lanzar
        inputManager.addMapping("Lanzar",
                new KeyTrigger(KeyInput.KEY_SPACE),
                new MouseButtonTrigger(MouseInput.BUTTON_LEFT));
        inputManager.addListener(actionListener, new String[]{"Lanzar"});

        // creamos la acción de comutar gravedad
        inputManager.addMapping("ConmutarGravedad", new KeyTrigger(KeyInput.KEY_G));
        inputManager.addListener(actionListener, new String[]{"ConmutarGravedad"});
    }
    
    /**
     * Se implementa el código a ejecutar en respuesta al uso de los controles
     * de interface del usuario
     */
    private ActionListener actionListener = new ActionListener() {
        public void onAction(String accion, boolean pulsado, float tpf) {
            // En el caso del lanzamiento de una bola
            if (accion.equals("Lanzar")) {
                // Creamos la bola cuando se pulsa el control
                if (pulsado) {
                    crearBola();
                // y la lanzamos al soltarlo    
                } else {
                    // Añadir la bola al motor de física
                    bulletAppState.getPhysicsSpace().add(bolaFis);
                    // ¡Empujar la bola en la dirección que mira la cámara a una velocidad
                    // de 8 metros por segundo
                    bolaFis.setLinearVelocity(cam.getDirection().mult(8));
                    sonidoLanzarBola.playInstance();
                }
            // en el caso de activar / desactivar la gravedad    
            } else if (accion.equals("ConmutarGravedad") ) {
                // Solo respondemos cuando se pulsa el control
                if (pulsado) {
                    if (gravedadActiva) {
                        bulletAppState.getPhysicsSpace().setGravity(Vector3f.ZERO);
                        gravedadActiva = false;
                    } else {
                        bulletAppState.getPhysicsSpace().setGravity(new Vector3f(0f, -9.81f, 0f));
                        gravedadActiva = true;
                    }
                }
            } 
        }
    };

    /**
     * No se realizará ninguna acción particular al actualizar
     * @param tpf
     */
    @Override
    public void simpleUpdate(float tpf) {
    }

    /**
     * No se realizará ninguna acción particular al redibujar
     * @param rm
     */
    @Override
    public void simpleRender(RenderManager rm) {
    }

    
}
