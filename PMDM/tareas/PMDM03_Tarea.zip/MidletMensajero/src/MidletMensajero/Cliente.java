package MidletMensajero;


/**
 * Clase para guardar los datos de un cliente para ser gestionado por la
 * clase MidletMensajero.
 * Se crean los metodos getter y setter para la entrada y recuperaci�n de la
 * informaci�n a gestionar, que consiste �nicamente en el nombre y telefono del
 * cliente as� como el Id con el que se guarda en el correspondiente RecordStore
 * de la aplicaci�n
 *
 * @author 
 */
public class Cliente {
    private int Id;
    private String Nombre;
    private String Numero;
    /**
     * Constructor de la clase. Inicializa todos los atributos de la clase con
     * valores no v�lidos.
     */
    public Cliente() {
        this.Nombre = "";
        this.Numero = "";
        this.Id = -1;
    }
    
    /**
     * Constructor de la clase
     * @param Nombre Valor para asignar al atributo Nombre
     * @param Numero Valor para asignar al atributo Numero
     */
    public Cliente(String Nombre, String Numero) {
        this.Nombre = Nombre;
        this.Numero = Numero;
        this.Id = -1;
    }

    /**
     * Constructor de la clase
     * @param Nombre Valor para asignar al atributo Nombre
     * @param Numero Valor para asignar al atributo Numero
     * @param Id Valor para asignar al atributo Id
     */
    public Cliente(String Nombre, String Numero, int Id) {
        this.Nombre = Nombre;
        this.Numero = Numero;
        this.Id = Id;
    }

    /**
     * Retorna el valor del atributo Id
     * @return Valor del atributo Id
     */
    public int getId() {
        return Id;
    }
    /**
     * Asigna un valor al atributo Id
     * @param Id Valor para asignar al atributo Id
     */
    public void setId(int Id) {
        this.Id = Id;
    }

    /**
     * Devuelve el valor del atributo Nombre
     * @return valro del atributo Nombre
     */
    public String getNombre() {
        return Nombre;
    }

    /**
     * Asigna un valor al atributo Nombre
     * @param Nombre Valor para asignar al atributo Nombre
     */
    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    /**
     * Devuelve el valor del atributo Numero
     * @return Valor del atributo Numero
     */
    public String getNumero() {
        return Numero;
    }

    /**
     * Asigna un valor al atributo Numero
     * @param Numero valor para asignar al atributo Numero
     */
    public void setNumero(String Numero) {
        this.Numero = Numero;
    }


    /**
     * Compone un texto con los valores de los atributos
     * @return String con el texto compuesto por los valores de los atributos
     *  Nombre y Numero
     */
    public String toStringDatos() {
        String datos;
        datos = "Nombre: " + Nombre + "\nTelefono: " + Numero;
        return datos;
    }
}
