package MidletMensajero;


import java.io.InputStream;
import java.util.Vector;
import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import javax.microedition.lcdui.Display;

/**
 * Clase en la que se implementan una serie de m�todos que pueden resultar de 
 * utilidad en esta y otras aplicaciones.
 * Los m�todos son en su mayor�a static para no tener necesidad de declarar un
 * objeto para ser utilizados.
 * 
 * @author 
  */
public class Util {
    
    /**
     * M�todo que muestra una alerta con el texto de una excepcion en el 
     * Display d pasado como parametro 
     * @param strTitulo Texto del t�tulo de la alerta
     * @param e Expcepci�n cuyo texto se quiere mostrar
     * @param d Display en el que se mostrar� la alerta
     */
    public static void mostrarErrorExcepcion(String strTitulo, Exception e, Display d) {
        Alert alerta = new Alert(strTitulo, e.toString(), null, AlertType.WARNING);
        alerta.setTimeout(Alert.FOREVER);
        d.setCurrent(alerta, d.getCurrent());
    }

    /**
     * M�todo que lee el archivo de texto pasado como par�metro y devuelve su
     * contenido en un String
     *
     * @param archivo nombre y ruta del archivo de texto a leer
     * @return String con el texto contenido en el fichero
     */
    public String leerArchivoTXT(String archivo) {
        InputStream is = getClass().getResourceAsStream(archivo);
        try {
            StringBuffer sb = new StringBuffer();
            int chr;
            // leemos caracteres y los vamos a�adiendo al buffer  hasta llegar
            // al final del fichero, momento en el que devolvemos el contenido
            // del mismo como un String
            while ((chr = is.read()) != -1) {
                sb.append((char) chr);
            }
            return sb.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    
   
    /**
     * Devuelve un vector de strings resultante de partir el string cadena en
     * subcadenas delimitadas por el string separador.<br> Similar a la funci�n
     * Split de la clase String de Java SE y que en Java ME no se encuentra
     * disponible (salvo que el resultado se devuelve en un vector en lugar de
     * en un array de Strings):
     *
     * @param cadena String del que se obtienen las subcadenas
     * @param separador Sring que se utiliza para delimitar las subcadenas
     * dentro de la cadena pasada como par�metro.
     * @return Vector que contiene las subcadenas obtenidas.
     */
    public static Vector split(String cadena, String separador) {
        Vector items = new Vector();
        // obtenemos la primera ocurrencia del String separador
        int pos = cadena.indexOf(separador);
        // mientra haya subcadenas
        while (pos >= 0) {
            // a�adimos  la subcadena al vector
            items.addElement(cadena.substring(0, pos));
            // y acortamos la cadena quitando la subcadena y el separador
            cadena = cadena.substring(pos + separador.length());
            pos = cadena.indexOf(separador);
        }
        items.addElement(cadena);
        return items;
    }
    
    /**
     * Devuelve una cadena de caracteres similar a la pasada como primer 
     * par�metro en la que se han reemplazado las ocurrencias del String a por 
     * el String b
     * 
     * @param cadena String en el se realizar�n los reemplazos
     * @param a String a ser sustituido
     * @param b String por el que se sustituir�n las ocurrencias del String a
     * @return String similar 
     */
    public static String replace(String cadena, String a, String b) {
        String cadenaFinal = "";
        // obtenemos la primera ocurrencia del String a
        int pos = cadena.indexOf(a);
        // mientra haya ocurrencias de a
        while (pos >= 0) {
            // a�adimos  la subcadena a la cadenaFinal y le a�adimos el string b
            cadenaFinal += cadena.substring(0, pos) + b;
            // y acortamos la cadena quitando la subcadena y el string a
            cadena = cadena.substring(pos + a.length());
            pos = cadena.indexOf(a);
        }
        cadenaFinal += cadena;
        return cadenaFinal;
    }
    
    public static void esperar(int milisegundos) {
        try {
            Thread.sleep(milisegundos);
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
    }
    
}
