package MidletMensajero;

import MidletMensajero.Util;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.util.Vector;
import javax.microedition.io.Connector;
import javax.microedition.lcdui.*;
import javax.microedition.midlet.MIDlet;
import javax.microedition.rms.RecordEnumeration;
import javax.microedition.rms.RecordStore;
import javax.microedition.rms.RecordStoreException;
import javax.wireless.messaging.MessageConnection;
import javax.wireless.messaging.TextMessage;

/**
 * Aplicaci�n correspondiente a la Tarea 3 del m�dulo de Programaci�n de
 * Dispositivos M�viles del ciclo Desarrollo de Aplicaciones Multiplataforma
 * <br>
 *
 * Permite gestionar una peque�a base de datos de clientes para poder enviarles
 * mensajes de publicidad.
 * La pantalla principal de la aplicaci�n contiene las siguientes opciones:<br>
 * <blockquote>- Explorar la lista de clientes.<br>
 *             - Modificar la plantilla de mensaje publicitario.<br>
 *             - Enviar mensaje publicitario a la lista de clientes.<br>
 *             - Salir de la aplicaci�n.<br> </blockquote>
 * Si se elige la primera opci�n (explorar la lista de clientes), obtenemos una
 * lista con los nombres de cada cliente pudi�ndose realizar las siguientes 
 * operaciones:
 * <blockquote>- Ver los datos de un cliente.<br>
 *             - A�adir un nuevo cliente.<br>
 *             - Eliminar un cliente.<br>
 *             - Modificar los datos un cliente.<br>
 *             - Volver a la pantalla principal.<br> </blockquote>
 * Los datos que se almacenan de un cliente son:
 * <blockquote>- Nombre.<br>
 *             - N�mero de tel�fono al que se enviar� el mensaje publicitario.
 * <br> </blockquote>
 * Si se elige la segunda opci�n de la pantalla principal (modificar la 
 * plantilla de mensaje publicitario), podemos editar el texto del mensaje que 
 * va a ser enviado. En ese texto podemos utilizar el car�cter "*". Ese car�cter
 * ser� sustituido por el nombre de cada cliente en cada mensaje individual.
 * Por ejemplo, si la plantilla dice "Enhorabuena *, has sido seleccionado 
 * para...", el mensaje que se le enviar� al cliente con nombre "Pedro" es 
 * "Enhorabuena Pedro, has sido seleccionado para...". <br>
 * Por �ltimo, la tercera opci�n (env�o de los mensajes), recorre la lista de 
 * clientes y env�a un mensaje de texto SMS personalizado a cada uno de ellos
 * bas�ndose en la plantilla de mensaje, sustituyendo el car�cter "*" por el
 * nombre del cliente.<br><br>
 *
 * Adem�s hay una pantalla de cr�ditos (nombre del autor, fecha, etc.), una
 * pantalla de instrucciones (indicando para qu� sirve la aplicaci�n y c�mo
 * puede usarse) y una pantalla de presentaci�n inicial con una imagen.<br><br>
 *
 * Para el manejo de la informaci�n referente a los cliente se ha
 * implementado la correspondiente clase <b>Clientes</b><br>
 * Asimismo se ha creado la clase <b>Util</b> en la que se han implementado
 * m�todos que facilitan algunas tareas a realizar y que pueden ser reutilizados
 * en otras aplicaciones<br><br>
 * 
 * Sevilla, enero 2013
 *
 * @author 
 * @see Cliente
 * @see Util
 */
public class MidletMensajero extends MIDlet implements CommandListener {
    /*
     * Constantes utilizadas en la aplicaci�n
     */
    public static final String STR_NULL = "";
    private static final String CLIENTES = "Clientes";
    private static final String IMG_SPLASH = "splash.png";

    // Ruta en la que se encuentran las im�genes de la aplicaci�n
    private static final String RUTA_IMAGENES = "/imagenes/";
    // Ruta en la que se encuentran los datos de la aplicaci�n
    private static final String ARCHIVO_DATOS = "/datos/datos.txt";
    
    // Constantes para definir los indices de los elementos del formSplash
    private static final int SPLASH_ITEM_TEXT = 1;

    /*
     * Constantes para los indices del array de String para los textos de la
     * aplicaci�n. Cualquier texto que se quiera a�adir a la aplicaci�n se
     * pondr� al final del fichero de datos y al final de esta lista con el
     * indice correspondiente.
     */
    private static int STR_VOLVER = 1;
    private static int STR_VER = 2;
    private static int STR_ERR_SPLASH = 3;
    private static int STR_CREDITOS = 4;
    private static int STR_INSTRUCCIONES = 5;
    private static int STR_LEYENDO_DATOS = 6;
    private static int STR_CREANDO_COMANDOS = 7;
    private static int STR_CREANDO_PANTALLAS = 8;
    private static int STR_ACEPTAR = 9;
    private static int STR_CANCELAR = 10;
    private static int STR_ALTA_CLIENTE = 11;
    private static int STR_MODIFICA_CLIENTE = 12;
    private static int STR_ETIQ_NOM = 13;
    private static int STR_ETIQ_TEL = 14;
    private static int STR_TXT_INSTR = 15;
    private static int STR_TXT_CRED = 16;
    private static int STR_TIT_FORM_PLANT = 17;
    private static int STR_INSTR_PLANT = 18;
    private static int STR_ETIQ_PLANT = 19;
    private static int STR_SI = 20;
    private static int STR_NO = 21;
    private static int STR_TIT_CONFIRM_BORRADO = 22;
    private static int STR_ERR_LISTANDO = 23;
    private static int STR_ERR_APERTURA_RS = 24;
    private static int STR_ABRIENDO_ALMACEN = 25;
    private static int STR_TIT_CRED = 26;
    private static int STR_PLANTILLA_VACIA = 27;
    private static int STR_LISTA_CLIENTES_VACIA = 28;
    private static int STR_NO_ENVIO_MENSAJES = 29;
    private static int STR_TIT_SALIDA = 30;
    private static int STR_TXT_SALIDA = 31;
    private static int STR_MENU_PRINCIPAL = 32;
    private static int STR_LISTADO_CLIENTES = 33;
    private static int ERR_GUARDANDO_CLIENTE = 34;
    private static int STR_ERR_BORRANDO_CLIENTE = 35;
    private static int STR_ERR_MODIFICANDO = 36;
    private static int STR_ERR_ENVIANDO = 37;
    private static int STR_SMS_ENVIADO = 38;

    // Constantes para definir los indices de las opciones del menu principal
    private static final int LISTADO = 0;
    private static final int PLANTILLA = 1;
    private static final int ENVIO = 2;
    private static final int SALIR = 3;

    // Constantes para definir los indices de las opciones del menu listados
    private static final int VER = 0;
    private static final int AGREGAR = 1;
    private static final int BORRAR = 2;
    private static final int MODIFICAR = 3;
    private static final int VOLVER = 4;

    // Constantes String auxiliares
    private static final String STR_COMODIN = "*";
    private static final String STR_MIDLET_MENSAJERO = "MidletMensajero";
    private static final String STR_SEPARADOR = "#";


    /*
    Displayables
     */
    // List para mostrar el menu principal y el listado de clientes
    private List listaMenuPrincipal, listaClientes;
    // Formulario de entrada, modificaci�n y visualizaci�n de clientes
    private Form formDatos;
    // Formulario para modificar la plantilla de SMS a enviar a los clientes
    private Form formPlantilla;
    // Formularios Instrucciones, Cr�ditos y Splash
    private Form formInstrucciones, formSplash;
    // Alertas para mostrar en caso de requerir confirmaci�n del usuario
    private Alert alertConfirmacionBorrado;
    private Alert alertConfirmacionSalida;

    /*
    Comandos para controlar la navegaci�n por las diferentes Displayables
     */
    private Command cmdVolver;
    private Command cmdCancelar;
    private Command cmdAceptar;
    private Command cmdCreditos;
    private Command cmdInstrucciones;
    private Command[] cmdOpcionesListado = new Command[5];
    // Display de la aplicaci�n
    private Display display;
    // Displayable para guardar el screen anterior a la llamada de los
    // form de instrucciones y cr�ditos
    private Displayable displayableAnterior;
    /*
    TextFields para el form de entrada, modificaci�n y visualizaci�n de
    los datos de clientes (nombre y tel�fono).
     */
    private TextField textFieldNombre;
    private TextField textFieldTelefono;
    // TextFields para el form de la plantilla de SMS a enviar a los clientes
    private TextField textFieldTextoPlantilla;

    /*
     * Variables para los textos de las posibles opciones del men� principal
     * y menu de la lista de clientes.
     */
    private static int nTotalOpcionesMenu = 4;
    private static int nTotalOpcionesListado = 5;
    // Array de String con las opciones del menu principal
    private String[] strOpcionMenu = new String[nTotalOpcionesMenu];
    // Array de String con las opciones de la pantalla listados
    private String[] strOpcionListado = new String[nTotalOpcionesListado];
    
    /*
     * String para guardar el texto de la plantilla para envio de SMS
     */
    private String strTextoPlantilla = STR_NULL;

    /*
    Vector para guardar los clientes que se encuentren en el RecordStore de
    manera que podamos establecer una relaci�n 1 a 1 entre los clientes del
    RecordStore (identificados por su Id) y el listado de clientes que se
    muestra en pantalla.
    De este modo, para recuperar los datos del cliente seleccionado en la
    lista de clientes de la pantalla haremos:
    int i = listaClientes.getSelectedIndex();
    Cliente cliente = (Cliente) vClientes.elementAt(i);
    int IdCliente = cliente.getId();
     */
    private Vector vClientes;

    /*
     * Milisegundos a esperar para ralentizar la presentaci�n del splash
     */
    private static int ESPERA = 1500;
    
    /*
     * Almacen de clientes
     */
    private RecordStore rs;

    /*
     * Array de String para almacenar los diferentes textos utilizados en la
     * aplicaci�n.
     */
    private String[] str;

    /**
     * Constructor de la clase de la aplicaci�n.<br> Ejecutamos las acciones que
     * se realizar�an por defecto al iniciarse la aplicaci�n, y seguidamente
     * leemos los datos del fichero de datos, creamos los diferentes comandos de
     * la aplicaci�n, as� como la pantalla del menu principal y la mostramos.
     * Durante la ejecuci�n se va actualizando y mostrando la pantalla de splash
     * con las acciones se van llevando a cabo.
     */
    public MidletMensajero() {
        super();
        crearFormSplash();
        display = Display.getDisplay(this);
        display.setCurrent(formSplash);
        // leemos los datos de la aplicaci�n y modificamos el texto mostrado
        // en la pantalla splash miestras se van procesando.
        // Se incluye un retardo de 1,5 segundos para hacer mas patente el efecto
        procesarArchivoDatos();
        ((StringItem) (formSplash.get(SPLASH_ITEM_TEXT))).setText(str[STR_LEYENDO_DATOS]);
        Util.esperar(ESPERA);
        ((StringItem) (formSplash.get(SPLASH_ITEM_TEXT))).setText(str[STR_CREANDO_COMANDOS]);
        crearComandos();
        Util.esperar(ESPERA);
        ((StringItem) (formSplash.get(SPLASH_ITEM_TEXT))).setText(str[STR_CREANDO_PANTALLAS]);
        crearFormInstrucciones();
        crearFormDatos();
        crearMenuPrincipal();
        crearFormPlantilla();
        Util.esperar(ESPERA);
        ((StringItem) (formSplash.get(SPLASH_ITEM_TEXT))).setText(str[STR_ABRIENDO_ALMACEN]);
        try {
            rs = RecordStore.openRecordStore(CLIENTES, true);
        } catch (RecordStoreException e) {
            Util.mostrarErrorExcepcion(str[STR_ERR_APERTURA_RS], e, display);
        }
        Util.esperar(ESPERA);
        display.setCurrent(listaMenuPrincipal);
    }

    /**
     * Implementaci�n del m�todo commandAction de la clase CommandListener que
     * se ser� llamado cuando se produzca un evento de comando sobre el
     * Displayable d
     *
     * @param c Comando desencadenante del evento
     * @param d Displayable pantalla sobre la que se ha producido el evento
     */
    public void commandAction(Command c, Displayable d) {
        /*
         * Opciones seleccionables desde el menu principal
         */
        if (c == List.SELECT_COMMAND && d == listaMenuPrincipal) {
            // recuperamos el indice de la opci�n seleccionada y actuamos en
            // consecuencia
            int opcion = listaMenuPrincipal.getSelectedIndex();
            // listar clientes

            if (opcion == LISTADO) {
                crearListaClientes();
                display.setCurrent(listaClientes);
            }

            // modificar plantilla del SMS
            else if(opcion == PLANTILLA) {
                display.setCurrent(formPlantilla);
            }
            
            // Enviar SMS a la lista de clientes
            else if(opcion == ENVIO) {
                // Ver si hay mensaje para enviar
                if (strTextoPlantilla.equals(STR_NULL)) {
                    Alert alerta = new Alert(str[STR_PLANTILLA_VACIA],
                            str[STR_NO_ENVIO_MENSAJES], null, AlertType.WARNING);
                    alerta.setTimeout(Alert.FOREVER);
                    display.setCurrent(alerta);
                } // Ver si hay clientes a los que enviar
                else if (vClientes == null || vClientes.isEmpty()) {
                    Alert alerta = new Alert(str[STR_LISTA_CLIENTES_VACIA],
                            str[STR_NO_ENVIO_MENSAJES], null, AlertType.WARNING);
                    alerta.setTimeout(Alert.FOREVER);
                    display.setCurrent(alerta);
                } // Si hay clientes y texto para enviar, enviar promocion
                else {
                    enviarPromocionSMS();
                }
            }

            // Antes de salir confirmar acci�n del usario
            else if (opcion == SALIR) {
                confirmarSalida();
            }
        }

        /*
         * Opciones seleccionables desde el listado de clientes
         */
        // Ver datos del cliente seleccionado
        else if(c == cmdOpcionesListado[VER]) {
            if (listaClientes.size() > 0) {
                verDatosClienteSeleccionado();
            }
        }

        // A�adir cliente
        else if(c == cmdOpcionesListado[AGREGAR]) {
            formDatos.setTitle(str[STR_ALTA_CLIENTE]);
            textFieldNombre.setString(STR_NULL);
            textFieldTelefono.setString(STR_NULL);
            display.setCurrent(formDatos);
        }

        // Borrar cliente seleccionado
        else if(c == cmdOpcionesListado[BORRAR]) {
            confirmarBorradoClienteSeleccionado();
        }

        // Modificar datos del cliente seleccionado
        else if(c == cmdOpcionesListado[MODIFICAR]) {
            int indice = listaClientes.getSelectedIndex();
            Cliente cliente = (Cliente) vClientes.elementAt(indice);
            formDatos.setTitle(str[STR_MODIFICA_CLIENTE]);
            textFieldNombre.setString(cliente.getNombre());
            textFieldTelefono.setString(cliente.getNumero());
            display.setCurrent(formDatos);
        }

        // Volver al men� principal
        else if(c == cmdOpcionesListado[VOLVER]) {
            display.setCurrent(listaMenuPrincipal);
        }

        /*
         * Opciones desde el formulario de instrucciones
         */
        // Volver a la pantalla anterir desde la que se llam� al formulario
        else if(c == cmdVolver && d == formInstrucciones) {
            display.setCurrent(displayableAnterior);
        }

        /*
         * Opciones desde el formulario de datos
         */
        // Llevar a cabo la acci�n para la que se llam� al formulario
        else if(c == cmdAceptar && d == formDatos) {
            Cliente cliente = new Cliente(textFieldNombre.getString(),
                    textFieldTelefono.getString());

            // El formulario se llam� para a�adir un cliente
            if (formDatos.getTitle().equals(str[STR_ALTA_CLIENTE])) {
                agregarCliente(cliente);
                crearListaClientes();
            }

            // El formulario se llam� para ver los datos de un cliente
            else if(formDatos.getTitle().equals(str[STR_VER])) {
                // Habilitamos los elementos del formulario que hab�an sido 
                // deshabilitados cuando se llam� para ver los datos del cliente
                textFieldNombre.setConstraints((textFieldNombre.getConstraints()
                        & TextField.CONSTRAINT_MASK));
                textFieldTelefono.setConstraints(
                        (textFieldTelefono.getConstraints()
                        & TextField.CONSTRAINT_MASK));
                formDatos.addCommand(cmdCancelar);
            } // El formulario se llam� para modificar los datos de un cliente

            else if(formDatos.getTitle().equals(str[STR_MODIFICA_CLIENTE])) {
                int i = listaClientes.getSelectedIndex();
                int id = ((Cliente) vClientes.elementAt(i)).getId();
                cliente.setId(id);
                // modificamos los datos del cliente con los nuevos datos
                reemplazarCliente(id, cliente);
            }
            // Tras realizar la acci�n correspondiente, regresamos al listado
            // de clientes
            display.setCurrent(listaClientes);
        }

        // Si se sale de la pantalla de datos cancelando, no hacer nada
        // Salimos de altas, modificaciones, sin aceptar los cambios
        else if(c == cmdCancelar && d == formDatos) {
            display.setCurrent(listaClientes);
        }

        /*
         * Opciones del formulario de modificaci�n de la plantilla para SMS
         */
        // Salimos de la modificaci�n de la plantilla de SMS aceptando,
        // guardamos los cambios y regresamos al men� principal
        else if(c == cmdAceptar && d == formPlantilla) {
            strTextoPlantilla = textFieldTextoPlantilla.getString();
            display.setCurrent(listaMenuPrincipal);
        }

        // Salimos de altas, modificaciones, sin aceptar los cambios
        // Salimos de la modificaci�n de la plantilla de SMS sin aceptar cambios
        else if(c == cmdCancelar && d == formPlantilla) {
            display.setCurrent(listaMenuPrincipal);
        }

        /*
         * Confirmaci�n del usuario previa al borrado de clientes
         */
        // Se ha pedido al usuario confirmaci�n de borrado
        else if (d == alertConfirmacionBorrado) {
            // liberar recurso Alert
            alertConfirmacionBorrado = null;
            // En caso de afirmar borrado, llevarlo a cabo y en cualquier caso
            // volver al listado de clientes recreando de nuevo la lista
            if (c.getLabel().equals(str[STR_SI])) {
                borrarClienteSeleccionado();
                crearListaClientes();
            }
            // En cualquier caso volver a mostrar el listado de clientes
            display.setCurrent(listaClientes);
        } // Se ha pedido al usuario confirmaci�n de salida
        
        /*
         * Confirmaci�n del usuario previa a la salida de la aplicaci�n
         */
        else if (d == alertConfirmacionSalida) {
            // En caso de afirmar salida, llevarlo a cabo y en cualquier caso
            // volver al listado de clientes recreando de nuevo la lista 
            if (c.getLabel().equals(str[STR_SI])) {
                destroyApp(true);
                notifyDestroyed();
            } // Si el usuario no quiere salir volvemos al menu principal
            else {
                display.setCurrent(listaMenuPrincipal);
            }
        }

        /*
         * Se ha pulsado ver instrucciones
         */
        else if (c == cmdInstrucciones) {
            // guardamos el displayable desde el que se ha solicitado antes de 
            // mostrar las instrucciones
            displayableAnterior = d;
            display.setCurrent(formInstrucciones);
        }

        /*
         *  Se ha pulsado ver cr�ditos
         */
        else if (c == cmdCreditos) {
            Alert alerta = new Alert(str[STR_TIT_CRED], str[STR_TXT_CRED], null, null);
            alerta.setTimeout(Alert.FOREVER);
            display.setCurrent(alerta);
            //display.setCurrent(formCreditos);
        }
    }



    public void startApp() {
    }

    public void pauseApp() {
    }

    public void destroyApp(boolean unconditional) {
    }

    /**
     * Crea los diferentes comandos que utilizar� la aplicaci�n en los
     * formularios
     */
    private void crearComandos() {
        cmdVolver = new Command(str[STR_VOLVER], Command.BACK, 3);
        cmdAceptar = new Command(str[STR_ACEPTAR], Command.SCREEN, 3);
        cmdCancelar = new Command(str[STR_CANCELAR], Command.SCREEN, 3);
        for (int i = 0; i < nTotalOpcionesListado; i++) {
            System.err.println("strOpcionListado[i] = " + strOpcionListado[i] );
            cmdOpcionesListado[i] = new Command(strOpcionListado[i],
                    Command.SCREEN, 3);
        }
        cmdInstrucciones = new Command(str[STR_INSTRUCCIONES], Command.SCREEN, 0);
        cmdCreditos = new Command(str[STR_CREDITOS], Command.SCREEN, 4);
    }

    /**
     * Crea el formulario inicial de la aplicaci�n que contiene la lista de
     * opciones disponibles por el usuario al iniciarse la aplicaci�n
     */
    private void crearMenuPrincipal() {
        listaMenuPrincipal = new List(str[STR_MENU_PRINCIPAL], List.IMPLICIT);
        for (int i = 0; i < this.nTotalOpcionesMenu; i++) {
            listaMenuPrincipal.insert(i, strOpcionMenu[i], null);
        }
        listaMenuPrincipal.addCommand(cmdInstrucciones);
        listaMenuPrincipal.addCommand(cmdCreditos);
        listaMenuPrincipal.setCommandListener(this);
    }

    /**
     * Crea el listado de los clientes en la pantalla.<br>
     *
     * Recorremos el RecordStore pasando el contenido del mismo a un
     * vector con los datos de los clientes, de modo que podamos
     * establecer una relaci�n 1 a 1 entre la lista de clientes que se
     * mostrar� en pantalla y los elementos de dicho vector. <br>
     * De este modo, para recuperar los datos del cliente seleccionado en la
     * lista de clientes de la pantalla haremos:<br><blockquote>
     * int i = listaClientes.getSelectedIndex();<br>
     * Cliente cliente = (Cliente) vClientes.elementAt(i);<br>
     * int IdCliente = cliente.getId(); </blockquote>
     *
     */
    private void crearListaClientes() {
        listaClientes = new List(str[STR_LISTADO_CLIENTES], List.IMPLICIT);
        try {
            byte[] byteInputData = new byte[100];
            vClientes = new Vector();
            ByteArrayInputStream is = new ByteArrayInputStream(byteInputData);
            DataInputStream dis = new DataInputStream(is);
            // Recorremos el RecordStore pasando el contenido del mismo a un
            // vector con los datos de los clientes, de modo que podamos 
            // establecer una relaci�n 1 a 1 entre la lista de clientes que se
            // mostrar� en pantalla y los elementos de dicho vector
            int i = 0;
            RecordEnumeration e = rs.enumerateRecords(null, null, true);
            while (e.hasNextElement()) {
                rs.getRecord(e.nextRecordId(), byteInputData, 0);
                Cliente cliente = new Cliente(dis.readUTF(),
                        dis.readUTF(), dis.read());
                vClientes.addElement(cliente);
                listaClientes.insert(i++, cliente.getNombre(), null);
                is.reset();
            }
            is.close();
        } catch (Exception e) {
            Util.mostrarErrorExcepcion(str[STR_ERR_LISTANDO], e, display);
        }
        // Si no hay clientes, activar solo AGREGAR y VOLVER
        if (vClientes.isEmpty()) {
            listaClientes.addCommand(cmdOpcionesListado[AGREGAR]);
            listaClientes.addCommand(cmdOpcionesListado[VOLVER]);
        } // Si hay clientes agregamos todas las opciones del men�
        else {
            for (int i = 0; i < cmdOpcionesListado.length; i++) {
                listaClientes.addCommand(cmdOpcionesListado[i]);
            }
        }
        // agregar las opciones para ver instrucciones o cr�ditos.
        listaClientes.addCommand(cmdInstrucciones);
        listaClientes.addCommand(cmdCreditos);
        // hacer que la aplicaci�n escuche al diplayable
        listaClientes.setCommandListener(this);
    }

    /**
     * Crea el formulario para mostrar la pantalla de altas, modificaciones o
     * visulazaci�n de los clientes. Consta de dos TextField que ser�n
     * habilitados o no en funci�n del uso que se le vaya a dar al formulario.
     * Asimismo, el texto de dichos TextField depender� del uso que se de al
     * formulario<br>
     * Se saldr� de la pantalla bien aceptando (cmdAceptar) o cancelando
     * (cmdCancelar) los cambios.
     */
    private void crearFormDatos() {
        formDatos = new Form(STR_NULL);
        textFieldNombre = new TextField(str[STR_ETIQ_NOM] + " ",
                STR_NULL, 30, TextField.ANY);
        textFieldTelefono = new TextField(str[STR_ETIQ_TEL] + " ",
                STR_NULL, 14, TextField.PHONENUMBER);
        formDatos.append(textFieldNombre);
        formDatos.append(textFieldTelefono);
        // agregar los comandos de interacci�n con el usuario
        formDatos.addCommand(cmdAceptar);
        formDatos.addCommand(cmdCancelar);
        // hacer que la aplicaci�n escuche al diplayable
        formDatos.setCommandListener(this);
    }

    /**
     * Crea el formulario para mostrar la pantalla de modificaci�n de la
     * plantilla para el envio de mensajes publicitarios. <br>
     * Se saldr� de la pantalla bien aceptando (cmdAceptar) o cancelando
     * (cmdCancelar) los cambios.
     */
    private void crearFormPlantilla() {
        formPlantilla = new Form(str[STR_TIT_FORM_PLANT]);
        StringItem strItem = new StringItem(STR_NULL, str[STR_INSTR_PLANT]);
        textFieldTextoPlantilla = new TextField(str[STR_ETIQ_PLANT] + " ",
                strTextoPlantilla, 160, TextField.ANY);
        formPlantilla.append(strItem);
        formPlantilla.append(textFieldTextoPlantilla);
        // agregar los comandos de interacci�n con el usuario
        formPlantilla.addCommand(cmdAceptar);
        formPlantilla.addCommand(cmdCancelar);
        // hacer que la aplicaci�n escuche al diplayable
        formPlantilla.setCommandListener(this);
    }

    /**
     * Crea el formulario de instrucciones a partir de los datos extraidos del
     * fichero de datos. Se saldr� del formulario pulsando la opcion de volver
     */
    private void crearFormInstrucciones() {
        StringItem strItemInstrucciones = new StringItem(STR_NULL, str[STR_TXT_INSTR]);
        formInstrucciones = new Form(str[STR_INSTRUCCIONES]);
        formInstrucciones.append(strItemInstrucciones);
        // agregar los comandos de interacci�n con el usuario
        formInstrucciones.addCommand(cmdVolver);
        // hacer que la aplicaci�n escuche al diplayable
        formInstrucciones.setCommandListener(this);
    }

   
    /**
     * Crear el formulario de splash con los elementos. En el m�todo constructor
     * de la clase se va modificando el valor del StringItem en funci�n de la
     * acci�n que est� realizando la aplicaci�n
     */
    private void crearFormSplash() {
        formSplash = new Form(STR_MIDLET_MENSAJERO);
        // cargamos la imagen para la pantalla splash
        Image img;// = null;
        ImageItem imgItem = null;
        try {
            img = Image.createImage(RUTA_IMAGENES + IMG_SPLASH);
            imgItem = new ImageItem(STR_NULL,
                    img,
                    Item.LAYOUT_CENTER | Item.LAYOUT_NEWLINE_AFTER,
                    STR_NULL);
        } catch (IOException ex) {
            Util.mostrarErrorExcepcion(str[STR_ERR_SPLASH], ex, display);
        }
        // creamos el texto a mostrar en pantalla splash
        String strTextoItemSplash = STR_NULL;
        StringItem strItem = new StringItem(STR_NULL, strTextoItemSplash);
        // agregamos los items al formulario
        formSplash.append(imgItem);
        formSplash.append(strItem);
    }

    /**
     * Lee el contenido del fichero con los literales utilizados en la 
     * aplicaci�n. Cada unos de los literales se guarda en el archivo de datos
     * separ�ndolos con un caracter #<br>
     * Esto se hace as� con el f�n de facilitar el mantenimiento y las posibles
     * transcripciones de la aplicaci�n a otros idiomas.
     * Cada literal que se quiera a�adir a la aplicaci�n deber� escribirse al 
     * final del archivo de datos y a�adir la constante de su indice al final de
     * la declaraci�n de constantes del tipo STR_
     */
    private void procesarArchivoDatos() {
        // Leemos el archivo
        Util util = new Util();
        String texto = util.leerArchivoTXT(ARCHIVO_DATOS);
        // obtenemos los datos de los literales y los guardamos en las variables 
        Vector vectorVar = Util.split((String) texto, STR_SEPARADOR);
        // los primeros literales son los correspondientes a las opciones de los
        // menus
        for (int i = 0; i < nTotalOpcionesMenu; i++) {
            strOpcionMenu[i] = ((String) vectorVar.elementAt(i)).trim();
        }

        for (int i = 0; i < nTotalOpcionesListado; i++) {
            strOpcionListado[i] = ((String) vectorVar.elementAt(i +
                    nTotalOpcionesMenu)).trim();
        }

        int nValores = vectorVar.size() - nTotalOpcionesMenu
                - nTotalOpcionesListado;
        str = new String[nValores];
        for (int i = 0; i < nValores; i++) {
            str[i] = ((String) vectorVar.elementAt(i + 9)).trim();
        }

    }

    /**
     * Agrega un nuevo cliente al almacen de clientes (RecordStore)<br>
     * Puesto que hemos de establecer una relaci�n 1 a 1 entre el listado de
     * clientes y los elementos del RecordStore, y esto lo hacemos a traves
     * de un vector de Clientes, antes de insertar el Cliente pasado como
     * par�metro, hemos de guardar en el mismo el valor de su Id llamando
     * previamente al m�todo <b>RecordStore.getNextRecordID()</b>.
     * De este modo, para recuperar los datos del cliente seleccionado en la
     * lista de clientes de la pantalla haremos:<br><blockquote>
     * int i = listaClientes.getSelectedIndex();<br>
     * Cliente cliente = (Cliente) vClientes.elementAt(i);<br>
     * int IdCliente = cliente.getId(); </blockquote>
     *
     *
     * @param cliente Cliente a insertar en el almacen
     */
    private void agregarCliente(Cliente cliente) {
        try {
            byte[] outputRecord;
            int Id = rs.getNextRecordID();
            ByteArrayOutputStream os = new ByteArrayOutputStream();
            DataOutputStream dos = new DataOutputStream(os);
            // Escribimos los datos en el stream, incluido el id con el que se
            // guardar� el registro.
            dos.writeUTF(cliente.getNombre());
            dos.writeUTF(cliente.getNumero());
            dos.write(Id);
            // limpiamos el stream
            dos.flush();
            // guardamos el registro
            outputRecord = os.toByteArray();
            Id = rs.addRecord(outputRecord, 0, outputRecord.length);
            cliente.setId(Id);
            vClientes.addElement(cliente);
            // cerramos el stream
            os.close();
            dos.close();
        } catch (Exception e) {
            Util.mostrarErrorExcepcion(str[ERR_GUARDANDO_CLIENTE], e, display);
        }
    }

    /**
     * Crea y muestra una alarma al usuario solicit�ndole confirmaci�n de
     * borrado del cliente actualmente seleccionado en la lista
     */
    private void confirmarBorradoClienteSeleccionado() {
        // Recuperamos los datos del cliente seleccionado en formato de String
        int indice = listaClientes.getSelectedIndex();
        String texto = ((Cliente) vClientes.elementAt(indice)).toStringDatos();
        // Creamos la alerta mostrando los datos del cliente
        alertConfirmacionBorrado = new Alert(str[STR_TIT_CONFIRM_BORRADO],
                texto, null, AlertType.CONFIRMATION);
        // A�adimos las opciones de la alerta
        alertConfirmacionBorrado.addCommand(new Command(str[STR_SI], Command.OK, 1));
        alertConfirmacionBorrado.addCommand(new Command(str[STR_NO], Command.CANCEL, 1));
        // Ponemos a la aplicaci�n a escuchar a la alerta
        alertConfirmacionBorrado.setCommandListener(this);
        // Y mostramos la alerta
        display.setCurrent(alertConfirmacionBorrado);
    }

    /**
     * Crea y muestra una alarma al usuario solicit�ndole confirmaci�n de
     * salida antes de salir de la aplicaci�n definitivamente
     */
    private void confirmarSalida() {
        // Creamos la alerta
        alertConfirmacionSalida = new Alert(str[STR_TIT_SALIDA],
                str[STR_TXT_SALIDA], null, AlertType.CONFIRMATION);
        // A�adimos las opciones de la alerta
        alertConfirmacionSalida.addCommand(new Command(str[STR_SI], Command.OK, 1));
        alertConfirmacionSalida.addCommand(new Command(str[STR_NO], Command.CANCEL, 1));
        // Ponemos a la aplicaci�n a escuchar a la alerta
        alertConfirmacionSalida.setCommandListener(this);
        // Y mostramos la alerta
        display.setCurrent(alertConfirmacionSalida);
    }

    /**
     * Elimina del RecordStore y del vector de clientes el cliente actualmente
     * seleccionado en la lista de clientes.
     */
    private void borrarClienteSeleccionado() {
        try {
            int i = listaClientes.getSelectedIndex();
            Cliente cliente = (Cliente) vClientes.elementAt(i);
            rs.deleteRecord(cliente.getId());
            vClientes.removeElementAt(i);
        } catch (Exception e) {
            Util.mostrarErrorExcepcion(str[STR_ERR_BORRANDO_CLIENTE], e, display);
        }
    }

    /**
     * Reemplaza los datos de un determinado registro del RecordStore con
     * los datos del cliente pasado como par�metro
     * @param id Identificador del cliente que se encuentra en el RecordStore
     * @param cliente Cliente que sustituir� al cliente con el Id pasado.
     */
    private void reemplazarCliente(int id, Cliente cliente) {
        try {
            byte[] outputRecord;
            ByteArrayOutputStream os = new ByteArrayOutputStream();
            DataOutputStream dos = new DataOutputStream(os);
            // escribimos los datos en el stream y los pasamos a un byte[]
            dos.writeUTF(cliente.getNombre());
            dos.writeUTF(cliente.getNumero());
            dos.write(cliente.getId());
            dos.flush();
            outputRecord = os.toByteArray();
            // y reemplazamos los datos en el registro correspondiente
            rs.setRecord(id, outputRecord, 0, outputRecord.length);
            // Modificamos el cliente en el vector de clientes
            int indice = listaClientes.getSelectedIndex();
            vClientes.removeElementAt(indice);
            vClientes.insertElementAt(cliente, indice);
        } catch (Exception e) {
            Util.mostrarErrorExcepcion(str[STR_ERR_MODIFICANDO], e, display);
        }
    }

    /**
     * Muestra el formulario de datos con los datos del cliente actualmente
     * seleccionado en la lista de clientes. Se inhabilitan los TextField
     * para impedir que el usuario realice cambios en los mismos. As�mismo se
     * elimina el comando cancelar. Estos cambios deber�n ser restablecidos
     * cuando el usuario pulse el comando aceptar (<b>commandAction</b>) de la
     * clase.
     */
    private void verDatosClienteSeleccionado() {
        // mostrar datos del cliente seleccionado
        int indice = listaClientes.getSelectedIndex();
        Cliente cliente = (Cliente) vClientes.elementAt(indice);
        formDatos.setTitle(str[STR_VER]);
        textFieldNombre.setString(cliente.getNombre());
        textFieldTelefono.setString(cliente.getNumero());
        // desactivamos los controles de texto
        textFieldNombre.setConstraints(
                (textFieldNombre.getConstraints() & TextField.CONSTRAINT_MASK)
                | TextField.UNEDITABLE);
        textFieldTelefono.setConstraints(
                (textFieldTelefono.getConstraints() & TextField.CONSTRAINT_MASK)
                | TextField.UNEDITABLE);
        // y quitamos el comando cancelar antes de mostrar el formulario de datos
        formDatos.removeCommand(cmdCancelar);
        display.setCurrent(formDatos);
    }

    /**
     * Se verifica que tanto la plantilla de texto para el SMS como la lista
     * de clientes contienen datos. En caso afirmativo se enviar� un SMS a cada
     * uno de los clientes. En caso contrario se muestra la correspondiente
     * alerta al usuario.
     */
    private void enviarPromocionSMS() {
        // Ver si hay mensaje para enviar
        if (strTextoPlantilla.equals(STR_NULL)) {
            Alert alerta = new Alert(str[STR_PLANTILLA_VACIA],
                    str[STR_NO_ENVIO_MENSAJES], null, AlertType.WARNING);
            alerta.setTimeout(Alert.FOREVER);
            display.setCurrent(alerta);
        }

        // Ver si hay clientes a los que enviar
        else if (vClientes == null || vClientes.isEmpty()) {
            Alert alerta = new Alert(str[STR_LISTA_CLIENTES_VACIA],
                    str[STR_NO_ENVIO_MENSAJES], null, AlertType.WARNING);
            alerta.setTimeout(Alert.FOREVER);
            display.setCurrent(alerta);
        }

        // Si hay clientes y texto para enviar, enviar promocion
        else {
            String strTexto = STR_NULL, strRes = STR_NULL;
            MessageConnection conn = null;
            TextMessage msg = null;
            for (int i = 0; i < vClientes.size(); i++) {
                Cliente cliente = (Cliente) vClientes.elementAt(i);
                strTexto = Util.replace(textFieldTextoPlantilla.getString(), STR_COMODIN, cliente.getNombre());

                try {
                    conn = (MessageConnection) Connector.open("sms://"
                            + cliente.getNumero());
                    msg = (TextMessage) conn.newMessage(MessageConnection.TEXT_MESSAGE);
                    msg.setPayloadText(strTexto);
                    conn.send(msg);
                    conn.close();
                    // Vamos construyendo el texto que se mostrar� al usuario
                    // indicando los mensajes que se han enviado
                    strRes = strRes + "\n" + cliente.getNumero() + ": " + strTexto;
                } catch (InterruptedIOException e) {
                    Util.mostrarErrorExcepcion(str[STR_ERR_ENVIANDO]
                            + cliente.getNombre(), e, display);
                } catch (IOException e) {
                    Util.mostrarErrorExcepcion(str[STR_ERR_ENVIANDO]
                            + cliente.getNombre(), e, display);
                }

            }
            // Mostramos al usuario el texto indicando los mensajes que se han enviado
            Alert alerta = new Alert(str[STR_SMS_ENVIADO], strRes, null, AlertType.INFO);
            alerta.setTimeout(Alert.FOREVER);
            display.setCurrent(alerta);
        }
    }
}
