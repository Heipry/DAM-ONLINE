package Tarea1Midlet;

import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.TextBox;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.midlet.*;

/**
 * Aplicación correspondiente a la Tarea 1 del módulo de Programación de 
 * Dispositivos Móviles del ciclo Desarrollo de Aplicaciones Multiplataforma
 *<br>
 * Escribe en pantalla el texto: "Esta es la tarea que me han encomendado 
 * realizar para dar por finalizada la unidad 1". Además de eso, el midlet
 * también incluye una opción con el texto "Fin" que cierra la aplicación.
 * <br>
 * Octubre 2012
 * 
 * @author 
 * @version 1.0
 */
public class Tarea1Midlet extends MIDlet implements CommandListener{

    TextBox msgTextBox; // Texto a mostrar
    Command finCommand; // Comando para salir de la aplicación

    
    public void commandAction(Command command, Displayable displayable) {
        if (displayable == msgTextBox) {
            if (command == finCommand) {
                Display.getDisplay(this).setCurrent(null);
                destroyApp(true);
                notifyDestroyed();
            }
        }
    }
    
    

    
    public void startApp() {
       msgTextBox = new TextBox(null, "Esta es la tarea que me han encomendado"
               + " realizar para dar por finalizada la unidad 1", 120, 0x0);
       finCommand = new Command("Fin", Command.EXIT, 1);
       msgTextBox.addCommand(finCommand);
       msgTextBox.setCommandListener(this);
       Display.getDisplay(this).setCurrent(msgTextBox);

    }
    
    public void pauseApp() {
    }
    
    public void destroyApp(boolean unconditional) {
    }
}